<?php
include ('includes/config.php');
session_start();

if(isset($_SESSION["uid"])){
  $uid = $_SESSION["uid"];
}
else{
  $uid = "";
}

if(isset($_POST["testimoni"])){
	$testimonial = $_POST["testimonial"];
	$status = 0;

	$check = "SELECT MAX(no) AS max FROM feedback";
    $rcheck = $conn->query($check);
    if($rcheck->num_rows>0){
      while($rowc = $rcheck->fetch_assoc()){
        $max = $rowc["max"];
      }
    }

    if($max < 10){
      $max++;
      $id = "F00" . $max;
    }
    else if($max < 100){
      $max++;
      $id = "F0" . $max;
    }
    else{
      $max++;
      $id = "F" . $max;
    }

	$insert = "INSERT INTO feedback (fid, uid, message, postdate, status) VALUES ('".$id."', '".$uid."', '".$testimonial."', NOW(), '".$status."')";
	if($conn->query($insert) == TRUE){
		echo "<meta http-equiv='refresh' content='0; url= post-testimonial.php?msg'/>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= post-testimonial.php?err'/>";
	}
}

if(isset($_POST["contact"])){
  $name = $_POST["name"];
  $email = $_POST["email"];
  $phoneno = $_POST["phoneno"];
  $message = $_POST["message"];
  $status = 0;

  $check = "SELECT MAX(no) AS max FROM contactus";
    $rcheck = $conn->query($check);
    if($rcheck->num_rows>0){
      while($rowc = $rcheck->fetch_assoc()){
        $max = $rowc["max"];
      }
    }

    if($max < 10){
      $max++;
      $id = "T00" . $max;
    }
    else if($max < 100){
      $max++;
      $id = "T0" . $max;
    }
    else{
      $max++;
      $id = "T" . $max;
    }

  $insert = "INSERT INTO contactus (contactid, name, email, phoneno, message, postdate, status) VALUES ('".$id."', '".$name."', '".$email."', '".$phoneno."', '".$message."', NOW(), '".$status."')";
  if($conn->query($insert) == TRUE){
    echo "<meta http-equiv='refresh' content='0; url= contact-us.php?msg'/>";
  }
  else{
    echo "<meta http-equiv='refresh' content='0; url= contact-us.php?err'/>";
  }
}

if(isset($_POST["hour"])){
  
  $kid = $_POST["kid"];
  $uid = $_POST["uid"];
  $compid = $_POST["compid"];
  $date = $_POST["fromdate"];
  $fromtime = $_POST["fromtime"];
  $totime = $_POST["totime"];
  $imgic = $_FILES["imgic"]["name"];
  $imglicense = $_FILES["imglicense"]["name"];
  $status = 0;

  $check = "SELECT MAX(no) AS max FROM booking";
  $rcheck = $conn->query($check);
  if($rcheck->num_rows>0){
    while($rowc = $rcheck->fetch_assoc()){
      $max = $rowc["max"];
    }
  }

  if($max < 10){
    $max++;
    $id = "B00" . $max;
  }
  else if($max < 100){
    $max++;
    $id = "B0" . $max;
  }
  else{
    $max++;
    $id = "B" . $max;
  }

  $targetDir = "assets/images/booking/";
  $targetFilePathic = $targetDir . $imgic;
  $targetFilePathlicense = $targetDir . $imglicense;

  if(move_uploaded_file($_FILES["imgic"]["tmp_name"], $targetFilePathic)){
    if(move_uploaded_file($_FILES["imglicense"]["tmp_name"], $targetFilePathlicense)){
      $book = "INSERT INTO booking (bookid, uid, compid, carid, fromdate, fromhour, tohour, icimg, licenseimg, postdate, status) VALUES ('".$id."', '".$uid."', '".$compid."', '".$kid."', '".$date."', '".$fromtime."', '".$totime."', '".$imgic."', '".$imglicense."', NOW(), '".$status."')";
      if($conn->query($book) == TRUE){
        $carbook = "UPDATE car SET status = 'occupied' WHERE carid = '".$kid."'";
        if($conn->query($carbook) == TRUE){
          echo "<script>alert('Car Booked! Awaiting for the conformation.');</script>";
          echo "<meta http-equiv='refresh' content='0; url= car-listing.php'/>";
        }
        else{
          echo "Oppss Something Wrong with the query";
        }
      }
      else{
        echo "Oppss Something Wrong with the query";
      }
    }
    else{
      echo "Oppss Something Wrong uploading license";
    }
  }
  else{
    echo "Oppss Something Wrong uploading ic.";
  }
}

if(isset($_POST["daily"])){
  
  $kid = $_POST["kid"];
  $uid = $_POST["uid"];
  $compid = $_POST["compid"];
  $fromdate = $_POST["fromdate"];
  $todate = $_POST["todate"];
  $imgic = $_FILES["imgic"]["name"];
  $imglicense = $_FILES["imglicense"]["name"];
  $status = 0;

  $check = "SELECT MAX(no) AS max FROM booking";
  $rcheck = $conn->query($check);
  if($rcheck->num_rows>0){
    while($rowc = $rcheck->fetch_assoc()){
      $max = $rowc["max"];
    }
  }

  if($max < 10){
    $max++;
    $id = "B00" . $max;
  }
  else if($max < 100){
    $max++;
    $id = "B0" . $max;
  }
  else{
    $max++;
    $id = "B" . $max;
  }

  $targetDir = "assets/images/booking/";
  $targetFilePathic = $targetDir . $imgic;
  $targetFilePathlicense = $targetDir . $imglicense;

  if(move_uploaded_file($_FILES["imgic"]["tmp_name"], $targetFilePathic)){
    if(move_uploaded_file($_FILES["imglicense"]["tmp_name"], $targetFilePathlicense)){
      $book = "INSERT INTO booking (bookid, uid, compid, carid, fromdate, todate, icimg, licenseimg, postdate, status) VALUES ('".$id."', '".$uid."', '".$compid."', '".$kid."', '".$fromdate."', '".$todate."', '".$imgic."', '".$imglicense."', NOW(), '".$status."')";
      if($conn->query($book) == TRUE){
        $car = "UPDATE car SET status = 'occupied' WHERE carid = '".$kid."'";
        if($conn->query($car) == TRUE){
          echo "<script>alert('Car Booked! Awaiting for the conformation.');</script>";
          echo "<meta http-equiv='refresh' content='0; url= car-listing.php'/>";
        }
        else{
           echo "Oppss Something Wrong with the query";
        }
      }
      else{
        echo "Oppss Something Wrong with the query";
      }
    }
    else{
      echo "Oppss Something Wrong uploading license";
    }
  }
  else{
    echo "Oppss Something Wrong uploading ic.";
  }
}