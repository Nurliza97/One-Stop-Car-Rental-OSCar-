<?php
session_start();
include('includes/config.php');
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  header('location:index.php');
}

if(isset($_GET["msg"])){
  $msg = "Profile Updated Successfully";
}
else{
  $msg = "";
}

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
    $email = $rowsql["email"];
    $phoneno = $rowsql["phoneno"];
    $address = $rowsql["address"];
    $poscode = $rowsql["poscode"];
    $state = $rowsql["state"];
    $date = $rowsql["regdate"];
    $ndate = date("d-m-Y", strtotime($date));
  }
}

$kid = "";
$img = "";
$from = "";
$to = "";
$brand = "";
$title = "";
$status = "";
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
<title>OSCaR | My Booking</title>
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
<!--slick-slider -->
<link href="assets/css/slick.css" rel="stylesheet">
<!--bootstrap-slider -->
<link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">

        
<!-- Google-Font-->
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
  
</head>
<body>

  
        
<!--Header-->
<?php include('includes/header.php');?>
<!--Page Header-->
<!-- /Header --> 

<!--Page Header-->
<section class="page-header profile_page">
  <div class="container">
    <div class="page-header_wrap">
      <div class="page-heading">
        <h1>My Booking</h1>
      </div>
      <ul class="coustom-breadcrumb">
        <li><a href="#">Home</a></li>
        <li>My Booking</li>
      </ul>
    </div>
  </div>
  <!-- Dark Overlay-->
  <div class="dark-overlay"></div>
</section>
<!-- /Page Header--> 

<section class="user_profile inner_pages">
  <div class="container">
    <div class="user_profile_info gray-bg padding_4x4_40">
      <div class="upload_user_logo"> <img src="assets/images/profile.png" alt="image">
      </div>

      <div class="dealer_info">
        <h5><?php echo $name;?></h5>
        <p><?php echo $address;?><br>
          <?php echo $poscode;?>&nbsp;<?php echo $state; ?></p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-3 col-sm-3">
       <?php include('includes/sidebar.php');?>
   
      <div class="col-md-6 col-sm-8">
        <div class="profile_wrap">
          <h5 class="uppercase underline">My Bookings </h5>
          <div class="my_vehicles_list">
            <ul class="vehicle_listing">
              <!-- Car query -->
              <?php
              $book = "SELECT *, a.status AS bstat FROM booking AS a INNER JOIN car AS b ON a.carid = b.carid INNER JOIN cardet AS c ON b.carid = c.carid WHERE uid = '".$uid."' ORDER BY postdate DESC";
              $rbook = $conn->query($book);
              if($rbook->num_rows>0){
                while($rowbook = $rbook->fetch_assoc()){
                  $kid = $rowbook["carid"];
                  $img = $rowbook["carimg1"];
                  $brand = $rowbook["brand"];
                  $title = $rowbook["title"];
                  $fdate = $rowbook["fromdate"];
                  $fromdate = date('d-m-Y', strtotime($fdate));
                  $tdate = $rowbook["todate"];
                  $todate = date('d-m-Y', strtotime($tdate));
                  $fromtime = $rowbook["fromhour"];
                  $totime = $rowbook["tohour"];
                  $status = $rowbook["bstat"];
                  
                  ?>
                  <li>
                    <div class="vehicle_img"> 
                      <a href="vehical-details.php?kid=<?php echo $kid;?>">
                        <img src="admin/img/vehicleimages/<?php echo $img;?>" alt="image">
                      </a> 
                    </div>
                    <div class="vehicle_title">
                      <h6>
                        <a href="vehical-details.php?kid=<?php echo $kid;?>"> <?php echo $brand;?> , <?php echo $title;?></a>
                      </h6>
                      <?php
                      if($fromtime != ""){
                        ?>
                        <p>
                          <b>Date:</b> <?php echo $fromdate;?><br/> 
                          <b>From Time:</b> <?php echo $fromtime;?><br/> 
                          <b>To Time:</b> <?php echo $totime;?></p>
                        <?php
                      }
                      else{
                        ?>
                        <p><b>From Date:</b> <?php echo $fromdate;?><br/> <b>To Date:</b> <?php echo $todate;?></p> 
                         <?php
                      }
                      ?>
                    </div>
                    <?php 
                    if($status == 1) { 
                      ?>
                      <div class="vehicle_status"> 
                        <a href="#" class="btn outline btn-xs active-btn">Confirmed</a>
                        <div class="clearfix"></div>
                      </div>
                      <?php 
                    } 
                    else if($status == 2) { 
                      ?>
                      <div class="vehicle_status"> 
                        <a href="#" class="btn outline btn-xs">Cancelled</a>
                        <div class="clearfix"></div>
                      </div>
                      <?php 
                    }
                    else if($status == 3) { 
                      ?>
                      <div class="vehicle_status"> 
                        <a href="#" class="btn outline btn-xs active-btn">Returned</a>
                        <div class="clearfix"></div>
                      </div>
                      <?php 
                    } 
                    else { 
                      ?>
                      <div class="vehicle_status"> 
                        <a href="#" class="btn outline btn-xs">Not Confirm yet</a>
                        <div class="clearfix"></div>
                      </div>
                      <?php
                    }
                    ?>
                  </li>
                  <?php
                }
              }
              else{
                ?>
                <h6 class="uppercase">No Booking History. </h6>
                <?php
              }
              ?>
              
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--/my-vehicles--> 
<!--Footer -->
<?php include('includes/footer.php');?>
<!-- /Footer--> 

<!--Back to top-->
<div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>
<!--/Back to top--> 

<!--Login-Form -->
<?php include('includes/login.php');?>
<!--/Login-Form --> 

<!--Register-Form -->
<?php include('includes/registration.php');?>
<?php include('includes/registercomp.php');?>
<!--/Register-Form --> 

<!--Forgot-password-Form -->
<?php include('includes/forgotpassword.php');?>
<!--/Forgot-password-Form --> 

<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 

<!--bootstrap-slider-JS--> 
<script src="assets/js/bootstrap-slider.min.js"></script> 
<!--Slider-JS--> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>
</body>
</html>
