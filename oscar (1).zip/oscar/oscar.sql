-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2020 at 01:02 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oscar`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `no` int(11) NOT NULL,
  `bookid` varchar(10) NOT NULL,
  `uid` varchar(10) NOT NULL,
  `compid` varchar(10) NOT NULL,
  `carid` varchar(10) NOT NULL,
  `fromdate` date NOT NULL,
  `todate` date NOT NULL,
  `fromhour` varchar(10) NOT NULL,
  `tohour` varchar(10) NOT NULL,
  `icimg` varchar(100) NOT NULL,
  `licenseimg` varchar(100) NOT NULL,
  `postdate` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE `car` (
  `no` int(11) NOT NULL,
  `carid` varchar(10) NOT NULL,
  `compid` varchar(10) NOT NULL,
  `carno` varchar(15) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `createdate` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cardet`
--

CREATE TABLE `cardet` (
  `no` int(11) NOT NULL,
  `detid` varchar(10) NOT NULL,
  `carid` varchar(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `rentalprice` varchar(100) NOT NULL,
  `priceday` int(11) NOT NULL,
  `state` varchar(10) NOT NULL,
  `modelyear` int(11) NOT NULL,
  `seatcapacity` int(11) NOT NULL,
  `carimg1` varchar(100) NOT NULL,
  `carimg2` varchar(100) NOT NULL,
  `carimg3` varchar(100) NOT NULL,
  `aircond` int(11) NOT NULL,
  `doorlock` int(11) NOT NULL,
  `antilock` int(11) NOT NULL,
  `breakeassist` int(11) NOT NULL,
  `powersteering` int(11) NOT NULL,
  `airbag` int(11) NOT NULL,
  `powerwindow` int(11) NOT NULL,
  `cdplayer` int(11) NOT NULL,
  `centrallock` int(11) NOT NULL,
  `crashsensor` int(11) NOT NULL,
  `leatherseat` int(11) NOT NULL,
  `passangerairbag` int(11) NOT NULL,
  `regdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `no` int(11) NOT NULL,
  `compid` varchar(10) NOT NULL,
  `uid` varchar(10) NOT NULL,
  `compname` varchar(100) NOT NULL,
  `compadd` varchar(100) NOT NULL,
  `compposcode` int(10) NOT NULL,
  `compstate` varchar(10) NOT NULL,
  `phoneno` int(12) NOT NULL,
  `qrimg` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `no` int(11) NOT NULL,
  `contactid` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phoneno` varchar(10) NOT NULL,
  `message` varchar(300) NOT NULL,
  `postdate` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `no` int(11) NOT NULL,
  `fid` varchar(10) NOT NULL,
  `uid` varchar(10) NOT NULL,
  `message` varchar(300) NOT NULL,
  `postdate` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `no` int(11) NOT NULL,
  `pageid` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `details` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`no`, `pageid`, `name`, `details`) VALUES
(1, 'terms', 'Terms and Conditions', 'test details'),
(2, 'privacy', 'Privacy Policy', 'test test'),
(3, 'aboutus', 'About Us ', 'test test'),
(4, 'faqs', 'FAQs', 'test test');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `no` int(10) NOT NULL,
  `uid` varchar(100) NOT NULL,
  `compid` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phoneno` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `poscode` int(10) NOT NULL,
  `state` varchar(10) NOT NULL,
  `password` varchar(50) NOT NULL,
  `regdate` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`no`, `uid`, `compid`, `name`, `email`, `phoneno`, `address`, `poscode`, `state`, `password`, `regdate`, `status`) VALUES
(1, 'superadmin', '', 'Super Admin', 'superadmin@gmail.com', '', '', 0, '', '123123', '0000-00-00', 'superadmin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `cardet`
--
ALTER TABLE `cardet`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `car`
--
ALTER TABLE `car`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cardet`
--
ALTER TABLE `cardet`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `page`
--
ALTER TABLE `page`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `no` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
