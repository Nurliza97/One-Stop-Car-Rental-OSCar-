<?php
session_start();
include('includes/config.php');
$_SESSION['url'] = $_SERVER['REQUEST_URI'];
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  header('location:index.php');
}

if(isset($_GET["msg"])){
  $msg = "Message sent. we will contact you shortly.";
}
else{
  $msg = "";
}

if(isset($_GET["err"])){
  $err = "Oppss, something went wrong.";
}
else{
  $err = "";
}

if(isset($_GET["kid"])){
  $kid = $_GET["kid"];
}
else{
  $kid = "";
}

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
    $email = $rowsql["email"];
    $phoneno = $rowsql["phoneno"];
    $address = $rowsql["address"];
    $poscode = $rowsql["poscode"];
    $state = $rowsql["state"];
    $date = $rowsql["regdate"];
    $ndate = date("d-m-Y", strtotime($date));
  }
}

$car = "SELECT * FROM car AS a INNER JOIN cardet AS b ON a.carid = b.carid INNER JOIN company AS c ON a.compid = c.compid WHERE a.carid = '".$kid."'";
$rcar = $conn->query($car);
if($rcar->num_rows>0){
  while($rowcar = $rcar->fetch_assoc()){
    $carno = $rowcar["carno"];
    $brand = $rowcar["brand"];
    $title = $rowcar["title"];
    $rentalprice = $rowcar["rentalprice"];
    $priceday = $rowcar["priceday"];
    $state = $rowcar["state"];
    $modelyear = $rowcar["modelyear"];
    $seatcapacity = $rowcar["seatcapacity"];
    $carimg1 = $rowcar["carimg1"];
    $carimg2 = $rowcar["carimg2"];
    $carimg3 = $rowcar["carimg3"];
    $aircond = $rowcar["aircond"];
    $doorlock = $rowcar["doorlock"];
    $antilock = $rowcar["antilock"];
    $breakeassist = $rowcar["breakeassist"];
    $powersteering = $rowcar["powersteering"];
    $airbag = $rowcar["airbag"];
    $powerwindow = $rowcar["powerwindow"];
    $cdplayer = $rowcar["cdplayer"];
    $centrallock = $rowcar["centrallock"];
    $crashsensor = $rowcar["crashsensor"];
    $leatherseat = $rowcar["leatherseat"];
    $passangerairbag = $rowcar["passangerairbag"];
    $regdate = $rowcar["regdate"];
    $qr = $rowcar["qrimg"];
    $compid = $rowcar["compid"];
  }
}
?>


<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
<title>OSCaR | Vehicle Details</title>
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
<!--slick-slider -->
<link href="assets/css/slick.css" rel="stylesheet">
<!--bootstrap-slider -->
<link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
</head>
<body>
<!--Header-->
<?php include('includes/header.php');?>
<!-- /Header --> 

<!--Listing-detail-->
<section class="listing-detail">
  <div class="container">
    <div class="row">
      <!--Side-Bar-->
      <aside class="col-md-9">
        <div class="sidebar_widget">
        	<form method="post" action="add_process.php" enctype="multipart/form-data">
          	
	            <h5><i class="fa fa-envelope" aria-hidden="true"></i> Book Now</h5>

	            <div class="form-group">
					<label>Scan to get direction</label>
					<div style="text-align: center;">
						<img src="admin/img/qr/<?php echo $qr ?>">	
					</div>
	              	
	            </div>
          
	            <div class="form-group">
					<label>Date</label>
	              	<input type="date" class="form-control" name="fromdate" id="fromdate" placeholder="From Date(dd/mm/yyyy)" onblur="showMMDD(this.value)" required>
	            </div>
				<div class="form-group">
					<label>Start Time</label>
					<div> 
						<select class="form-control" name="fromtime" required>
							<option value=""> Select </option>
							<option value="00:00">00:00</option>
							<option value="06:00">06:00</option>
							<option value="07:00">07:00</option>
							<option value="08:00">08:00</option>
							<option value="09:00">09:00</option>
							<option value="10:00">10:00</option>
							<option value="11:00">11:00</option>
							<option value="12:00">12:00</option>
							<option value="13:00">13:00</option>
							<option value="14:00">14:00</option>
							<option value="15:00">15:00</option>
							<option value="16:00">16:00</option>
							<option value="17:00">17:00</option>
							<option value="18:00">18:00</option>
							<option value="19:00">19:00</option>
							<option value="20:00">20:00</option>
							<option value="21:00">21:00</option>
							<option value="22:00">22:00</option>
							<option value="23:00">23:00</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label>End Time</label>
					<div>
						<select class="form-control" name="totime" required>
							<option value=""> Select </option>
							<option value="00:00">00:00</option>
							<option value="06:00">06:00</option>
							<option value="07:00">07:00</option>
							<option value="08:00">08:00</option>
							<option value="09:00">09:00</option>
							<option value="10:00">10:00</option>
							<option value="11:00">11:00</option>
							<option value="12:00">12:00</option>
							<option value="13:00">13:00</option>
							<option value="14:00">14:00</option>
							<option value="15:00">15:00</option>
							<option value="16:00">16:00</option>
							<option value="17:00">17:00</option>
							<option value="18:00">18:00</option>
							<option value="19:00">19:00</option>
							<option value="20:00">20:00</option>
							<option value="21:00">21:00</option>
							<option value="22:00">22:00</option>
							<option value="23:00">23:00</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label>IC Image</label>
					<input style="padding-top: 10px;" accept="image/*" type="file" class="form-control" name="imgic" required>
				</div>
				<div class="form-group">
					<label>License Image</label>
					<input style="padding-top: 10px;" accept="image/*" type="file" class="form-control" name="imglicense" required>
				</div>
	          	<?php 
	          	if($uid != ""){
	          		?>
	              	<div class="form-group">
	              		<input type="hidden" name="kid" value="<?php echo $kid ?>">
	              		<input type="hidden" name="uid" value="<?php echo $uid ?>">
	              		<input type="hidden" name="compid" value="<?php echo $compid ?>">
	                	<input type="submit" class="btn" name="hour" value="Book Now">
	              	</div>
	          		<?php 
	          	} 
	          	else { 
	          		?>
					<a href="#loginform" class="btn btn-xs uppercase" data-toggle="modal" data-dismiss="modal">Login For Booking</a>
	              	<?php 
	          	} 
	          	?>
          	</form>
        </div>
  	</aside>
      <!--/Side-Bar--> 
    </div>
  </div>
</section>
<!--/Listing-detail--> 

<!--Footer -->
<?php include('includes/footer.php');?>
<!-- /Footer--> 

<!--Back to top-->
<div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>
<!--/Back to top--> 

<!--Login-Form -->
<?php include('includes/login.php');?>
<!--/Login-Form --> 

<!--Register-Form -->
<?php include('includes/registration.php');?>
<?php include('includes/registercomp.php');?>
<!--/Register-Form --> 

<!--Forgot-password-Form -->
<?php include('includes/forgotpassword.php');?>
<!--/Forgot-password-Form -->

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 
<script src="assets/switcher/js/switcher.js"></script>
<script src="assets/js/bootstrap-slider.min.js"></script> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>

<script src="serviceMap.js"></script>

</body>

<script>
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
 if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 

today = yyyy+'-'+mm+'-'+dd;



document.getElementById("fromdate").setAttribute("min", today);


function showMMDD(d) {
  
  
  var CDate = new Date(d);
  var newDate = new Date(CDate);
  
  
  var dd = newDate.getDate()+1;
  var mm = newDate.getMonth()+1;
  var y = newDate.getFullYear();
  
  if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 

newDate = yyyy+'-'+mm+'-'+dd;
  
  

  document.getElementById("todate").setAttribute("min", newDate);
}

</script>

</html>