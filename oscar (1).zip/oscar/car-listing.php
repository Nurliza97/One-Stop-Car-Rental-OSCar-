<?php
session_start();
include('includes/config.php');
$_SESSION['url'] = $_SERVER['REQUEST_URI'];
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  $uid = "";
}

if(isset($_GET["msg"])){
  $msg = "Message sent. we will contact you shortly.";
}
else{
  $msg = "";
}

if(isset($_GET["err"])){
  $err = "Oppss, something went wrong.";
}
else{
  $err = "";
}

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
    $email = $rowsql["email"];
    $phoneno = $rowsql["phoneno"];
    $address = $rowsql["address"];
    $poscode = $rowsql["poscode"];
    $state = $rowsql["state"];
    $date = $rowsql["regdate"];
    $ndate = date("d-m-Y", strtotime($date));
  }
}

?>

<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
<title>OSCaR | Car Listing</title>
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
<!--slick-slider -->
<link href="assets/css/slick.css" rel="stylesheet">
<!--bootstrap-slider -->
<link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">


<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
</head>
<body>



<!--Header--> 
<?php include('includes/header.php');?>
<!-- /Header --> 

<!--Page Header-->
<section class="page-header listing_page">
  <div class="container">
    <div class="page-header_wrap">
      <div class="page-heading">
        <h1>Car Listing</h1>
      </div>
      <ul class="coustom-breadcrumb">
        <li><a href="#">Home</a></li>
        <li>Car Listing</li>
      </ul>
    </div>
  </div>
  <!-- Dark Overlay-->
  <div class="dark-overlay"></div>
</section>
<!-- /Page Header--> 

<!--Listing-->
<section class="listing-page">
  <div class="container">
    <div class="row">
      <?php
      $car = "SELECT * FROM car AS a INNER JOIN cardet AS b ON a.carid = b.carid WHERE a.status = 'free'";

      if(isset($_POST["search"])){
        
        if($_POST["brand"] != ""){
          $sbrand = $_POST["brand"];
          $car .= " AND brand = '".$sbrand."'";
        }

        if($_POST["state"] != ""){
          $sstate = $_POST["state"];
          $car .= " AND state = '".$sstate."'";
        }
      }

      $rcar = $conn->query($car);
      if($rcar->num_rows>0){
        while($rowcar = $rcar->fetch_assoc()){
          $kid = $rowcar["carid"];
          $brand = $rowcar["brand"];
          $title = $rowcar["title"];
          $priceday = $rowcar["priceday"];
          $seat = $rowcar["seatcapacity"];
          $modelyear = $rowcar["modelyear"];
          $state = $rowcar["state"];
          $img = $rowcar["carimg1"];
          ?>
          <div class="col-md-9 col-md-push-3">
            <div class="result-sorting-wrapper">
              <div class="sorting-count">
                <div class="product-listing-m gray-bg">
                  <div class="product-listing-img"><img src="admin/img/vehicleimages/<?php echo $img;?>" class="img-responsive" alt="Image" /> </a> 
                  </div>
                  <div class="product-listing-content">
                    <h5><a href="vehical-details.php?kid=<?php echo $kid;?>"><?php echo $brand;?> , <?php echo $title;?></a></h5>
                    <p class="list-price">RM <?php echo $priceday;?> Per Day</p>
                    <ul>
                      <li><i class="fa fa-user" aria-hidden="true"></i><?php echo $seat;?> seats</li>
                      <li><i class="fa fa-calendar" aria-hidden="true"></i><?php echo $modelyear; ?> model</li>
                      <li><i class="fa fa-car" aria-hidden="true"></i><?php echo$state;?></li>
                    </ul>
                    <a href="vehical-details.php?kid=<?php echo $kid;?>" class="btn">View Details <span class="angle_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php
        }
      }
      else{
        ?>
        <div class="col-md-9 col-md-push-3">
            <div class="result-sorting-wrapper">
              <div class="sorting-count">
                <div class="product-listing-m gray-bg">
                  Sorry No Data
                </div>
              </div>
            </div>
          </div>
        <?php
      }
      ?>
      
      
      <!--Side-Bar-->
      <aside class="col-md-3 col-md-pull-9">
        <div class="sidebar_widget" style="margin-top:-1900px;">
          <div class="widget_heading">
            <h5><i class="fa fa-filter" aria-hidden="true"></i> Find Your  Car </h5>
          </div>
          <div class="sidebar_filter">
            <form action="#" method="POST">
              <div class="form-group select">
                <select class="form-control" name="brand">
                  <option value="">Select Brand</option>
                  <?php
                  $brand = "SELECT * FROM car GROUP BY brand";
                  $rbrand = $conn->query($brand);
                  if($rbrand->num_rows>0){
                    while($rowbrand = $rbrand->fetch_assoc()){
                      $brand = $rowbrand["brand"];
                      ?>
                      <option value="<?php echo $brand ?>"><?php echo $brand ?></option>
                      <?php
                    }
                  }
                  ?>
                </select>
              </div>
              <div class="form-group select">
                <select class="form-control" name="state">
                  <option value="">Select Your State</option>
                  <option value="Selangor">Selangor</option>
                  <option value="Melaka">Melaka</option>
                  <option value="N9">Negeri Sembilan</option>
                  <option value="Johor">Johor</option>
                  <option value="Kedah">Kedah</option>
                  <option value="Pulau Pinang">Pulau Pinang</option>
                  <option value="Perak">Perak</option>
                </select>
              </div>
              <div class="form-group">
                <button type="submit" name="search" class="btn btn-block"><i class="fa fa-search" aria-hidden="true"></i> Search Car</button>
              </div>
            </form>
          </div>
        </div>
        <div class="sidebar_widget">
          <div class="widget_heading">
            <h5><i class="fa fa-car" aria-hidden="true"></i> Recently Listed Cars</h5>
          </div>
          <div class="recent_addedcars">
            <ul>
              <?php
              $recent = "SELECT * FROM car AS a INNER JOIN cardet AS b ON a.carid = b.carid WHERE a.status = 'free' ORDER BY a.createdate LIMIT 3";
              $rcent = $conn->query($recent);
              if($rcent->num_rows>0){
                while($rowcent = $rcent->fetch_assoc()){
                  $kid = $rowcent["carid"];
                  $brand = $rowcent["brand"];
                  $title = $rowcent["title"];
                  $priceday = $rowcent["priceday"];
                  $img = $rowcent["carimg1"];
                  ?>
                  <li class="gray-bg">
                    <div class="recent_post_img"> <a href="vehical-details.php?kid=<?php echo $kid;?>"><img src="admin/img/vehicleimages/<?php echo $img;?>" alt="image"></a> </div>
                    <div class="recent_post_title"> <a href="vehical-details.php?kid=<?php echo $kid;?>"><?php echo $brand;?> , <?php echo $title;?></a>
                      <p class="widget_price">RM <?php echo $priceday;?> Per Day</p>
                    </div>
                  </li> 
                  <?php
                }
              }
              ?>
            </ul>
          </div>
        </div>
      </aside>
      <!--/Side-Bar--> 
    </div>
  </div>
</section>
<!-- /Listing--> 

<!--Footer -->
<?php include('includes/footer.php');?>
<!-- /Footer--> 

<!--Back to top-->
<div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>
<!--/Back to top--> 

<!--Login-Form -->
<?php include('includes/login.php');?>
<!--/Login-Form --> 

<!--Register-Form -->
<?php include('includes/registration.php');?>
<?php include('includes/registercomp.php');?>
<!--/Register-Form --> 

<!--Forgot-password-Form -->
<?php include('includes/forgotpassword.php');?>
<!--/Forgot-password-Form --> 

<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 

<!--bootstrap-slider-JS--> 
<script src="assets/js/bootstrap-slider.min.js"></script> 
<!--Slider-JS--> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>

</body>
</html>
