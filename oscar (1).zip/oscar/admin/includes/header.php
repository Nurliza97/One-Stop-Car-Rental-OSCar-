<div class="brand clearfix">
	<span class="menu-btn"><i class="fa fa-bars"></i></span>
	<ul class="ts-profile-nav">
		
		<li class="ts-account">
			<a href="#"><img src="img/profile.png" class="ts-avatar hidden-side" alt="">
				<?php 
				$name1 = explode(' ', $name); 
				$name2 = $name1[0];
				echo $name2;
				?> 
				<i class="fa fa-angle-down hidden-side"></i></a>
			<ul>
				<li><a href="change-password.php">Change Password</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</li>
	</ul>
</div>
