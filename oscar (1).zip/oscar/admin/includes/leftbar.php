	<nav class="ts-sidebar">
		<ul class="ts-sidebar-menu">
		
			<li class="ts-label">Main</li>
			<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>

			<li><a href="#"><i class="fa fa-car"></i> Vehicles</a>
				<ul>
					<li><a href="post-avehical.php">Insert Vehicle</a></li>
					<li><a href="manage-vehicles.php">Manage Vehicles</a></li>
				</ul>
			</li>
			<li><a href="manage-bookings.php"><i class="fa fa-users"></i> Manage Booking</a></li>
			<li><a href="bookings-history.php"><i class="fa fa-calendar"></i> Booking History</a></li>
			<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Update Contact Info</a></li>
		 	<?php
          	if($status == "admin"){
	            ?>
	            <li><a href="#"><i class="fa fa-user"></i> Staff</a>
				<ul>
					<li><a href="register-staff.php">Register Staff</a></li>
					<li><a href="manage-staff.php">Manage Staff</a></li>
				</ul>
			</li>
	            <?php
          	}
          	?>

		</ul>
	</nav>