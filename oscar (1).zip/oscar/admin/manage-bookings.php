<?php
session_start();
include('includes/config.php');
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  header('Location: ../index.php');
}

if(isset($_SESSION['compid'])){ 
  $compid = $_SESSION["compid"];
}
else{
  $compid = "";
}

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
    $status = $rowsql["status"];
  }
}

?>

<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>OSCaR | Admin | Manage Bookings</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
  	<style>
		.errorWrap {
		    padding: 10px;
		    margin: 0 0 20px 0;
		    background: #fff;
		    border-left: 4px solid #dd3d36;
		    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		}
		.succWrap{
		    padding: 10px;
		    margin: 0 0 20px 0;
		    background: #fff;
		    border-left: 4px solid #5cb85c;
		    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		}
		.dataTables_filter, .dataTables_info { 
			display: none; 
		}
	</style>

</head>

<body>
	<?php include('includes/header.php');?>

	<div class="ts-main-content">
		<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h2 class="page-title">Manage Bookings</h2>
						<!-- Zero Configuration Table -->
						<div class="panel panel-default">
							<div class="panel-heading">Bookings Info</div>
							<div class="panel-body">
							<?php 
								if(isset($_GET["err"])){
									?>
									<div class="errorWrap">
										<strong>ERROR</strong>: <?php echo $err; ?> 
									</div>
									<?php 
								} 
								else if(isset($_GET["msg"])){
									?>
									<div class="succWrap">
										<strong>SUCCESS</strong>:<?php echo $msg; ?> 
									</div>
									<?php 
								}
								?>
								<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>#</th>
											<th>Name</th>
											<th>Car</th>
											<th>From Date</th>
											<th>From Time</th>
											<th>To Date</th>
											<th>To Time</th>
											<th>IC Image</th>
											<th>License Image</th>
											<th>Posting date</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<?php
										$i = 0;
										$book = "SELECT *, a.status AS bstat FROM booking AS a INNER JOIN user AS b ON a.uid = b.uid INNER JOIN car AS c ON a.carid = c.carid INNER JOIN cardet AS d ON c.carid = d.carid WHERE a.compid = '".$compid."' AND a.status = 0 ORDER BY a.postdate ASC";
										$rbook = $conn->query($book);
										if($rbook->num_rows>0){
											while($rowbook = $rbook->fetch_assoc()){
												$i++;
												$bid = $rowbook["bookid"];
												$carid = $rowbook["carid"];
												$name = $rowbook["name"];
												$brand = $rowbook["brand"];
												$title = $rowbook["title"];
												$fdate = $rowbook["fromdate"];
												$fromdate = date('d-m-Y', strtotime($fdate));
												$fromhour = $rowbook["fromhour"];
												$tdate = $rowbook["todate"];
												$todate = date('d-m-Y', strtotime($tdate));
												$tohour = $rowbook["tohour"];
												$icimg = $rowbook["icimg"];
												$licenseimg = $rowbook["licenseimg"];
												$status = $rowbook["bstat"];
												$pdate = $rowbook["postdate"];
												$postdate = date('d-m-Y', strtotime($pdate));
												?>
												<tr>
													<td><?php echo htmlentities($i);?></td>
													<td><?php echo $name;?></td>
													<td><a href="edit-vehicle.php?id=<?php echo $carid;?>"><?php echo $brand;?> , <?php echo $title;?></td>
													<td><?php echo $fromdate;?></td>
													<td>
														<?php 
														if($fromhour == ""){
															echo "-";
														}
														else{
															echo $fromhour;	
														}
														?>
													</td>
													<td>
														<?php 
														if($tdate == "0000-00-00"){
															echo "-";
														}
														else{
															echo $todate;
														}
														?>	
													</td>
													<td>
														<?php 
														if($tohour == ""){
															echo "-";
														}
														else{
															echo $tohour;	
														}
														;
														?>
													</td>
													
													<td><a href="../assets/images/booking/<?php echo $icimg;?>"><?php echo $icimg;?></a></td>
													<td><a href="../assets/images/booking/<?php echo $licenseimg; ?>"><?php echo $licenseimg;?></a></td>
													<td><?php echo $postdate;?></td>
													<td>
														<a href="update_process.php?appbook=<?php echo $bid;?>" onclick="return confirm('Do you really want to Confirm this booking?')"> Confirm</a> /
														<a href="update_process.php?rejbook=<?php echo $bid;?>&carid=<?php echo $carid ?>" onclick="return confirm('Do you really want to Cancel this booking?')"> Cancel</a>
													</td>
												</tr>
												<?php
											}
										}
										?>
										
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>
</html>
