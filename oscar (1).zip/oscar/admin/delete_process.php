<?php
include ('includes/config.php');
session_start();

if(isset($_SESSION["uid"])){
  $uid = $_SESSION["uid"];
}
else{
  header('Location: ../index.php');
}

if(isset($_SESSION['compid'])){ 
  $compid = $_SESSION["compid"];
}
else{
  $compid = "";
}

if(isset($_GET["vec"])){
	$carid = $_GET["vec"];

	$delete = "DELETE FROM car WHERE carid = '".$carid."'";
	if($conn->query($delete) == TRUE){
		$deldetails = "DELETE FROM cardet WHERE carid = '".$carid."'";
		if($conn->query($deldetails) == TRUE){
			echo "<meta http-equiv='refresh' content='0; url= manage-vehicles.php?msg'/>";
		}
		else{
			echo "<meta http-equiv='refresh' content='0; url= manage-vehicles.php?err'/>";
		}
	}
}

if(isset($_GET["staff"])){
	$sid = $_GET["staff"];

	$delete = "DELETE FROM user WHERE uid = '".$sid."'";
	if($conn->query($delete) == TRUE){
		echo "<meta http-equiv='refresh' content='0; url= manage-staff.php?msg'/>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= manage-staff.php?err'/>";
	}
}
?>