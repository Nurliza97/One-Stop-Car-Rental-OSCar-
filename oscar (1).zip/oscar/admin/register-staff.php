<?php
session_start();
include('includes/config.php');
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  header('Location: ../index.php');
}

if(isset($_SESSION['compid'])){ 
  $compid = $_SESSION["compid"];
}
else{
  $compid = "";
}

$err = "";

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
    $status = $rowsql["status"];
  }
}
if(isset($_GET["msg"])){
	$msg=" Staff Registered Successfull";
}

if(isset($_GET["err"])){
	$err=" Oppss Something Wrong.";	
}

if(isset($_GET["id"])){
	$sid=$_GET["id"];	
}

$staffname = "";
$address = "";
$phoneno = "";
$state = "";
$poscode = "";
$email = "";

if(isset($_GET["edit"])){
	$edit = "SELECT * FROM user WHERE uid = '".$sid."'";
	$redit = $conn->query($edit);
	if($redit->num_rows>0){
		while($rowedit = $redit->fetch_assoc()){
			$staffname = $rowedit["name"];
			$address = $rowedit["address"];
			$phoneno = $rowedit["phoneno"];
			$state = $rowedit["state"];
			$poscode = $rowedit["poscode"];
			$email = $rowedit["email"];
		}
	}
}	

?>
<!DOCTYPE HTML>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>OSCaR | Admin | Register Staff</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
	<style>
		.errorWrap {
		    padding: 10px;
		    margin: 0 0 20px 0;
		    background: #fff;
		    border-left: 4px solid #dd3d36;
		    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		}
		.succWrap{
		    padding: 10px;
		    margin: 0 0 20px 0;
		    background: #fff;
		    border-left: 4px solid #5cb85c;
		    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		}
	</style>

</head>
<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h2 class="page-title">Register Staff</h2>
						<?php
						if(isset($_GET["edit"])){
							?>
							<form method="POST" class="form-horizontal" action="update_process.php" >
							<?php
						}
						else{
							?>
							<form method="POST" class="form-horizontal" action="add_process.php" >
							<?php
						}
						?>
							<div class="row">
								<div class="col-md-12">
									<div class="panel panel-default">
										<div class="panel-heading">Basic Info</div>
										<?php if(isset($_GET["err"])){
											?>
											<div class="errorWrap">
												<strong>ERROR</strong>:<?php echo $err; ?> 
											</div>
											<?php 
										} 
										else if(isset($_GET["msg"])){
											?>
											<div class="succWrap">
												<strong>SUCCESS</strong>:<?php echo $msg; ?> 
											</div>
											<?php 
										}
										?>
										<div class="panel-body">
											<div class="form-group">
												<label class="col-sm-2 control-label">Name<span style="color:red">*</span></label>
												<div class="col-sm-10">
												<input type="text" name="staffname" class="form-control" value="<?php echo $staffname ?>" required>
												</div>
											</div>
											<div class="hr-dashed"></div>
											<div class="form-group">
												<label class="col-sm-2 control-label">Email<span style="color:red">*</span></label>
												<div class="col-sm-4">
													<?php
													if(isset($_GET["edit"])){
														?>
														<input type="email" name="email" class="form-control" value="<?php echo $email ?>" readonly>
														<?php
													}
													else{
														?>
														<input type="email" name="email" class="form-control" value="<?php echo $email ?>" required>
														<?php
													}
													?>
												</div>
												<label class="col-sm-2 control-label">Phone Number<span style="color:red">*</span></label>
												<div class="col-sm-4">
												<input type="text" name="phoneno" class="form-control" value="<?php echo $phoneno ?>" maxlength="10" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
												</div>
											</div>
											<div class="form-group">
												<label class="col-sm-2 control-label">Address<span style="color:red">*</span></label>
												<div class="col-sm-10">
													<textarea class="form-control" name="address" rows="3" required><?php echo $address ?></textarea>
												</div>
											</div>
											<div class="form-group">
												<label class="col-sm-2 control-label">Postcode<span style="color:red">*</span></label>
												<div class="col-sm-4">
													<input type="text" name="poscode" class="form-control" value="<?php echo $poscode ?>" maxlength="5" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
												</div>
												<label class="col-sm-2 control-label">State<span style="color:red">*</span></label>
												<div class="col-sm-4">
													<input type="text" name="state" class="form-control" value="<?php echo $state ?>" required>
												</div>
											</div>
											<?php
											if(!isset($_GET["edit"])){
												?>
												<div class="form-group">
													<label class="col-sm-2 control-label">Password<span style="color:red">*</span></label>
													<div class="col-sm-4">
														<input type="password" name="password" id="password" class="form-control" required>
													</div>
													<label class="col-sm-2 control-label">Confirm Password<span style="color:red">*</span></label>
													<div class="col-sm-4">
														<input type="password" name="confirmpass" id="confirmpass" class="form-control" required>
													</div>
												</div>	
												<?php
											}
											?>										
											<div class="hr-dashed"></div>									
										</div>
									</div>
								</div>
								<div class="form-group" style="text-align: center;">
									<?php
									if(isset($_GET["edit"])){
										?>
										<input type="hidden" name="sid" value="<?php echo $sid ?>">
										<button class="btn btn-default" type="reset">Cancel</button>
										<button class="btn btn-primary" style="width: 120px;" name="updatestaff" type="submit">Save changes</button>
										<?php
									}
									else{
										?>
										<input type="hidden" name="compid" value="<?php echo $compid ?>">
										<button class="btn btn-primary" style="width: 120px;" name="addstaff" type="submit">Save</button>
										<?php
									}
									?>
									
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Loading Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/fileinput.js"></script>
<script src="js/chartData.js"></script>
<script src="js/main.js"></script>

</body>
<script type="text/javascript">
    var password = document.getElementById("password")
      , confirm_password = document.getElementById("confirmpass");

    function validatePassword(){
      if(password.value != confirm_password.value) {
        confirm_password.setCustomValidity("Passwords Don't Match");
      } else {
        confirm_password.setCustomValidity('');
      }
    }

    password.onchange = validatePassword;
    confirm_password.onkeyup = validatePassword;
</script>
</html>
