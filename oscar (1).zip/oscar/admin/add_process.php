<?php
include ('includes/config.php');
session_start();
error_reporting(0);

if(isset($_SESSION["uid"])){
  $uid = $_SESSION["uid"];
}
else{
  header('Location: ../index.php');
}

if(isset($_SESSION['compid'])){ 
  $compid = $_SESSION["compid"];
}
else{
  $compid = "";
}

if(isset($_POST["addcar"])){

	$title = $_POST["title"];
	$brand = $_POST["brand"];
	$platno = $_POST["platno"];
	$rentalprice = $_POST["rentalprice"];
	$priceperday = $_POST["priceperday"];
	$state = $_POST["state"];
	$modelyear = $_POST["modelyear"];
	$seatingcapacity = $_POST["seatingcapacity"];
	$img1 = $_FILES["img1"]["name"];
	$img2 = $_FILES["img2"]["name"];
	$img3 = $_FILES["img3"]["name"];


	$airconditioner = $_POST["airconditioner"];
	$powerdoorlocks = $_POST["powerdoorlocks"];
	$antilockbrakingsys = $_POST["antilockbrakingsys"];
	$brakeassist = $_POST["brakeassist"];
	$powersteering = $_POST["powersteering"];
	$driverairbag = $_POST["driverairbag"];
	$passengerairbag = $_POST["passengerairbag"];
	$powerwindow = $_POST["powerwindow"];
	$cdplayer = $_POST["cdplayer"];
	$centrallocking = $_POST["centrallocking"];
	$crashcensor = $_POST["crashcensor"];
	$leatherseats = $_POST["leatherseats"];

	$check = "SELECT MAX(no) AS max FROM car";
  	$rcheck = $conn->query($check);
  	if($rcheck->num_rows>0){
	    while($rowc = $rcheck->fetch_assoc()){
	      $max = $rowc["max"];
	    }
  	}

  	if($max < 10){
	    $max++;
	    $carid = "K00" . $max;
  	}
  	else if($max < 100){
	    $max++;
	    $carid = "K0" . $max;
  	}
  	else{
	    $max++;
	    $carid = "K" . $max;
  	}

  	$check = "SELECT MAX(no) AS max FROM cardet";
  	$rcheck = $conn->query($check);
  	if($rcheck->num_rows>0){
	    while($rowc = $rcheck->fetch_assoc()){
	      $max = $rowc["max"];
	    }
  	}

  	if($max < 10){
	    $max++;
	    $id = "D00" . $max;
  	}
  	else if($max < 100){
	    $max++;
	    $id = "D0" . $max;
  	}
  	else{
	    $max++;
	    $id = "D" . $max;
  	}

  	$targetDir = "img/vehicleimages/";
  	$targetFilePathimg1 = $targetDir . $img1;
  	$targetFilePathimg2 = $targetDir . $img2;
  	$targetFilePathimg3 = $targetDir . $img3;

  	if(move_uploaded_file($_FILES["img1"]["tmp_name"], $targetFilePathimg1)){
    	if(move_uploaded_file($_FILES["img2"]["tmp_name"], $targetFilePathimg2)){
    		if(move_uploaded_file($_FILES["img3"]["tmp_name"], $targetFilePathimg3)){
    			$insert = "INSERT INTO car (carid, compid, carno, brand, createdate, status) VALUES ('".$carid."', '".$compid."', '".$platno."', '".$brand."', NOW(), 'free')";
    			if($conn->query($insert) == TRUE){
    				$details = "INSERT INTO cardet (detid, carid, title, rentalprice, priceday, state, modelyear, seatcapacity, carimg1, carimg2, carimg3, aircond, doorlock, antilock, breakeassist, powersteering, airbag, powerwindow, cdplayer, centrallock, crashsensor, leatherseat, passangerairbag, regdate) VALUES ('".$id."', '".$carid."', '".$title."', '".$rentalprice."', '".$priceperday."', '".$state."', '".$modelyear."', '".$seatingcapacity."', '".$img1."', '".$img2."', '".$img3."', '".$airconditioner."', '".$powerdoorlocks."', '".$antilockbrakingsys."', '".$brakeassist."', '".$powersteering."', '".$driverairbag."', '".$powerwindow."', '".$cdplayer."', '".$centrallocking."', '".$crashcensor."', '".$leatherseats."', '".$passengerairbag."', NOW())";
    				if($conn->query($details) == TRUE){
    					echo "<meta http-equiv='refresh' content='0; url= post-avehical.php?msg'/>";
    				}
    				else{
    					echo "Error : " . $details . "<br>" . $conn->error;
    				}
    			}
    			else{
					echo "Error : " . $insert . "<br>" . $conn->error;
				}
    		}
    		else{
    			echo "Error Img 3";
    		}
    	}
    	else{
    		echo "Error Img 2";
    	}
    }
    else{
    	echo "Error Img 1";
    }
}	

if(isset($_POST["addstaff"])){
  $compid = $_POST["compid"];
  $name = $_POST["staffname"];
  $staffemail = $_POST["email"];
  $phone = $_POST["phoneno"];
  $address = $_POST["address"];
  $poscode = $_POST["poscode"];
  $state = $_POST["state"];
  $password = $_POST["password"];
  $status = "staff";

  $email = "SELECT email FROM user WHERE email = '".$staffemail."'";
  $remail = $conn->query($email);
  if($remail->num_rows>0){
    while ($rowemail = $remail->fetch_assoc()) {
      echo "<script>alert('Email already Exist!');</script>";
      echo "<meta http-equiv='refresh' content='0; url= register-staff.php'/>";
    }
  }
  else{
    $check = "SELECT MAX(no) AS max FROM user";
    $rcheck = $conn->query($check);
    if($rcheck->num_rows>0){
      while($rowc = $rcheck->fetch_assoc()){
        $max = $rowc["max"];
      }
    }

    if($max < 10){
      $max++;
      $id = "U00" . $max;
    }
    else if($max < 100){
      $max++;
      $id = "U0" . $max;
    }
    else{
      $max++;
      $id = "U" . $max;
    }

    $sql = "INSERT INTO user (uid, compid, name, email, phoneno, address, poscode, state, password, regdate, status) VALUES ('".$id."', '".$compid."', '".$name."', '".$staffemail."', '".$phone."', '".$address."', '".$poscode."', '".$state."', '".$password."', NOW(), '".$status."')";
    if($conn->query($sql) == TRUE){
       echo "<script>alert('Staff Registered.');</script>";
       echo "<meta http-equiv='refresh' content='0; url= manage-staff.php'/>";
    }
    else{
      echo "<script>alert('Oppss something went wrong.');</script>";
      echo "<meta http-equiv='refresh' content='0; url= register-staff.php'/>";
    }
  }	
}	
?>