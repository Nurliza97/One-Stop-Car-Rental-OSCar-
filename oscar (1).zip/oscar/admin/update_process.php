<?php
session_start();
include('includes/config.php');
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  header('Location: ../index.php');
}

if(isset($_SESSION['compid'])){ 
  $compid = $_SESSION["compid"];
}
else{
  $compid = "";
}

if(isset($_POST["contact"])){
	$add = $_POST["address"];
	$phone = $_POST["contactno"];

	$update = "UPDATE company SET compadd = '".$add."', phoneno = '".$phone."' WHERE compid = '".$compid."'";
	if($conn->query($update) == TRUE){
		echo "<meta http-equiv='refresh' content='0; url= update-contactinfo.php?msg'/>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= update-contactinfo.php?err'/>";
	}
}

if(isset($_POST["changepass"])){
	$pass = $_POST["password"];
	$npass = $_POST["newpassword"];

	$check = "SELECT * FROM user WHERE uid = '".$uid."'";
	$rcheck = $conn->query($check);
	if($rcheck->num_rows>0){
		while($rowcheck = $rcheck->fetch_assoc()){
			$cpass = $rowcheck["password"];
		}
	}

	if($pass == $cpass){
		$update = "UPDATE user SET password = '".$npass."' WHERE uid = '".$uid."'";
		if($conn->query($update) == TRUE){
			echo "<meta http-equiv='refresh' content='0; url= change-password.php?msg'/>";
		}
		else{
			echo "<meta http-equiv='refresh' content='0; url= change-password.php?err2'/>";
		}
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= change-password.php?err'/>";
	}

	
}

if(isset($_POST["carimg"])){
	$no = $_POST["no"];
	$kid = $_POST["kid"];
	$img = $_FILES["img"]["name"];

	$targetDir = "img/vehicleimages/";
	$targetFilePathimg1 = $targetDir . $img;

	if(move_uploaded_file($_FILES["img"]["tmp_name"], $targetFilePathimg1)){
		$update = "UPDATE cardet SET carimg".$no." = '".$img."' WHERE carid = '".$kid."'";
		if($conn->query($update) == TRUE){
			echo "<meta http-equiv='refresh' content='0; url= edit-vehicle.php?id=$kid'/>";
		}
		else{
			echo "<meta http-equiv='refresh' content='0; url= edit-vehicle.php?id=$kid'/>";
		}
	}
}

if(isset($_POST["vehicle"])){
	$kid = $_POST["kid"];
	$title = $_POST["title"];
	$brand = $_POST["brand"];
	$platno = $_POST["platno"];
	$rentalprice = $_POST["rentalprice"];
	$priceperday = $_POST["priceperday"];
	$state = $_POST["state"];
	$modelyear = $_POST["modelyear"];
	$seatingcapacity = $_POST["seatingcapacity"];

	$airconditioner = $_POST["airconditioner"];
	$powerdoorlocks = $_POST["powerdoorlocks"];
	$antilockbrakingsys = $_POST["antilockbrakingsys"];
	$brakeassist = $_POST["brakeassist"];
	$powersteering = $_POST["powersteering"];
	$driverairbag = $_POST["driverairbag"];
	$passengerairbag = $_POST["passengerairbag"];
	$powerwindow = $_POST["powerwindow"];
	$cdplayer = $_POST["cdplayer"];
	$centrallocking = $_POST["centrallocking"];
	$crashcensor = $_POST["crashcensor"];
	$leatherseats = $_POST["leatherseats"];

	$update = "UPDATE car SET carno = '".$platno."', brand='".$brand."' WHERE carid = '".$kid."'";
	if($conn->query($update) == TRUE){
		$updatedet = "UPDATE cardet SET title = '".$title."', rentalprice = '".$rentalprice."', priceday = '".$priceperday."', modelyear = '".$modelyear."', seatcapacity = '".$seatingcapacity."', aircond = '".$airconditioner."', doorlock = '".$powerdoorlocks."', antilock = '".$antilockbrakingsys."', breakeassist = '".$brakeassist."', airbag = '".$driverairbag."', powerwindow = '".$powerwindow."', cdplayer = '".$cdplayer."', centrallock = '".$centrallocking."', crashsensor = '".$crashcensor."', leatherseat = '".$leatherseats."', passangerairbag = '".$passengerairbag."' WHERE carid = '".$kid."'";
		if($conn->query($updatedet) == TRUE){
			echo "<meta http-equiv='refresh' content='0; url= edit-vehicle.php?msg&id=$kid'/>";
		}
		else{
			echo "<meta http-equiv='refresh' content='0; url= edit-vehicle.php?err&id=$kid'/>";
		}
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= edit-vehicle.php?err&id=$kid'/>";
	}
}

if(isset($_POST["updatestaff"])){
  	$sid = $_POST["sid"];
  	$name = $_POST["staffname"];
  	$phone = $_POST["phoneno"];
  	$address = $_POST["address"];
  	$poscode = $_POST["poscode"];
  	$state = $_POST["state"];

	$sql = "UPDATE user SET name = '".$name."', phoneno = '".$phone."', address = '".$address."', poscode = '".$poscode."', state = '".$state."' WHERE uid = '".$sid."'";
    if($conn->query($sql) == TRUE){
       echo "<script>alert('Staff Updated.');</script>";
       echo "<meta http-equiv='refresh' content='0; url= manage-staff.php'/>";
    }
    else{
      echo "<script>alert('Oppss something went wrong.');</script>";
      echo "<meta http-equiv='refresh' content='0; url= register-staff.php?id=$sid&edit'/>";
    }
}

if(isset($_GET["appbook"])){
  	$bid = $_GET["appbook"];

	$sql = "UPDATE booking SET status = '1' WHERE bookid = '".$bid."'";
    if($conn->query($sql) == TRUE){
       echo "<script>alert('Booking Confirmed.');</script>";
       echo "<meta http-equiv='refresh' content='0; url= manage-bookings.php'/>";
    }
    else{
      echo "<script>alert('Oppss something went wrong.');</script>";
      echo "<meta http-equiv='refresh' content='0; url= manage-bookings.php'/>";
    }
}

if(isset($_GET["rejbook"])){
  	$bid = $_GET["rejbook"];
  	$carid = $_GET["carid"];

	$sql = "UPDATE booking SET status = '2' WHERE bookid = '".$bid."'";
    if($conn->query($sql) == TRUE){
    	$car = "UPDATE car SET status = 'free' WHERE carid = '".$carid."'";
    	if($conn->query($car) == TRUE){
    		echo "<script>alert('Booking Cancelled.');</script>";
       		echo "<meta http-equiv='refresh' content='0; url= manage-bookings.php'/>";
    	}
    	else{
    		echo "<script>alert('Oppss something went wrong.');</script>";
      		echo "<meta http-equiv='refresh' content='0; url= manage-bookings.php'/>";
    	}
    }
    else{
      echo "<script>alert('Oppss something went wrong.');</script>";
      echo "<meta http-equiv='refresh' content='0; url= manage-bookings.php'/>";
    }
}

if(isset($_GET["retcar"])){
  	$bid = $_GET["retcar"];
  	$carid = $_GET["carid"];

	$sql = "UPDATE booking SET status = '3' WHERE bookid = '".$bid."'";
    if($conn->query($sql) == TRUE){
    	$car = "UPDATE car SET status = 'free' WHERE carid = '".$carid."'";
    	if($conn->query($car) == TRUE){
    		echo $car;
	       // echo "<script>alert('Car Returned.');</script>";
	       // echo "<meta http-equiv='refresh' content='0; url= bookings-history.php'/>";
	   	}
	   	else{
	   		echo "<script>alert('Oppss something went wrong.');</script>";
      	echo "<meta http-equiv='refresh' content='0; url= bookings-history.php'/>";
	   	}
    }
    else{
      echo "<script>alert('Oppss something went wrong.');</script>";
      echo "<meta http-equiv='refresh' content='0; url= bookings-history.php'/>";
    }
}
?>