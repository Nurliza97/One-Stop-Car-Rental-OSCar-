<?php
session_start();
include('includes/config.php');
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  header('Location: ../index.php');
}

if(isset($_SESSION['compid'])){ 
  $compid = $_SESSION["compid"];
}
else{
  $compid = "";
}

if(isset($_GET["kid"])){
	$kid = $_GET["kid"];
}
else{
	$kid = "";
}

if(isset($_GET["no"])){
	$no = $_GET["no"];
}
else{
	$no = "";
}

$err = "";

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
    $status = $rowsql["status"];
  }
}
if(isset($_GET["msg"])){
	$msg=" Image Updated Successfull";
}

if(isset($_GET["err"])){
	$err=" Oppss Something Wrong.";	
}
?>

<!DOCTYPE HTML>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>OSCaR | Admin | Update Image <?php echo $no ?></title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
  	<style>
		.errorWrap {
		    padding: 10px;
		    margin: 0 0 20px 0;
		    background: #fff;
		    border-left: 4px solid #dd3d36;
		    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		}
		.succWrap{
		    padding: 10px;
		    margin: 0 0 20px 0;
		    background: #fff;
		    border-left: 4px solid #5cb85c;
		    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
		}
		</style>
</head>

<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h2 class="page-title">Update Image <?php echo $no ?> </h2>

						<div class="row">
							<div class="col-md-10">
								<div class="panel panel-default">
									<div class="panel-heading">Vehicle Image <?php echo $no ?> Details</div>
									<div class="panel-body">
										<form method="post" action="update_process.php" class="form-horizontal" enctype="multipart/form-data">											
						  	        	  	<?php 
						  	        	  	if(isset($_GET["err"])){
						  	        	  		?>
						  	        	  		<div class="errorWrap">
						  	        	  			<strong>ERROR</strong>:<?php echo htmlentities($err); ?> 
						  	        	  		</div>
						  	        	  		<?php 
						  	        	  	} 
											else if(isset($_GET["msg"])){
												?>
												<div class="succWrap">
													<strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> 
												</div>
												<?php 
											}
											?>
											<div class="form-group">
												<label class="col-sm-4 control-label">Current Image <?php echo $no ?></label>
												<div class="col-sm-8">
													<?php
													$carimg = "SELECT carimg".$no." AS carimg FROM cardet WHERE carid = '".$kid."'";
													$rimg = $conn->query($carimg);
													if($rimg->num_rows>0){
														while($rowimg = $rimg->fetch_assoc()){
															$carimg = $rowimg["carimg"];
														}
													}
													?>
													<img src="img/vehicleimages/<?php echo $carimg;?>" width="300" height="200" style="border:solid 1px #000">
												</div>
											</div>
											<div class="form-group">
												<label class="col-sm-4 control-label">Upload New Image <?php echo $no ?><span style="color:red">*</span></label>
												<div class="col-sm-8 control-label">
													<input type="file" name="img" required>
												</div>
											</div>
											<div class="hr-dashed"></div>
											<div class="form-group">
												<div class="col-sm-8 col-sm-offset-4">
													<input type="hidden" name="no" value="<?php echo $no ?>">
													<input type="hidden" name="kid" value="<?php echo $kid ?>">
													<button class="btn btn-primary" name="carimg" type="submit">Update</button>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>			
			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
