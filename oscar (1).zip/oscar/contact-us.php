<?php
session_start();
include('includes/config.php');
$_SESSION['url'] = $_SERVER['REQUEST_URI'];
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  $uid = "";
}

if(isset($_GET["msg"])){
  $msg = "Message sent. we will contact you shortly.";
}
else{
  $msg = "";
}

if(isset($_GET["err"])){
  $err = "Oppss, something went wrong.";
}
else{
  $err = "";
}

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
    $email = $rowsql["email"];
    $phoneno = $rowsql["phoneno"];
    $address = $rowsql["address"];
    $poscode = $rowsql["poscode"];
    $state = $rowsql["state"];
    $date = $rowsql["regdate"];
    $ndate = date("d-m-Y", strtotime($date));
  }
}

?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
<title>OSCaR | Contact Us</title>
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
<!--slick-slider -->
<link href="assets/css/slick.css" rel="stylesheet">
<!--bootstrap-slider -->
<link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">

<!-- SWITCHER -->
<link rel="stylesheet" id="switcher-css" type="text/css" href="assets/switcher/css/switcher.css" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/red.css" title="red" media="all" data-default-color="true" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/orange.css" title="orange" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/blue.css" title="blue" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/pink.css" title="pink" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/green.css" title="green" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/purple.css" title="purple" media="all" />
        

<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
 <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>
</head>
<body>

 
        
<!--Header-->
<?php include('includes/header.php');?>
<!-- /Header --> 

<!--Page Header-->
<section class="page-header contactus_page">
  <div class="container">
    <div class="page-header_wrap">
      <div class="page-heading">
        <h1>Contact Us</h1>
      </div>
      <ul class="coustom-breadcrumb">
        <li><a href="#">Home</a></li>
        <li>Contact Us</li>
      </ul>
    </div>
  </div>
  <!-- Dark Overlay-->
  <div class="dark-overlay"></div>
</section>
<!-- /Page Header--> 

<!--Contact-us-->
<section class="contact_us section-padding">
  <div class="container">
    <div  class="row">
      <div class="col-md-6">
        <h3>Get in touch with us</h3>
          <?php 
          if($err){
            ?>
            <div class="errorWrap">
              <strong>ERROR</strong>: <?php echo $err; ?> 
            </div>
            <?php 
          } 
          else if($msg){
            ?>
              <div class="succWrap">
                <strong>SUCCESS</strong>: <?php echo $msg; ?>
              </div>
            <?php 
          }?>
          <div class="contact_form gray-bg">
            <form  method="post" action="add_process.php">
              <div class="form-group">
                <label class="control-label">Full Name <span>*</span></label>
                <input type="text" name="name" class="form-control white_bg" id="fullname" required>
              </div>
              <div class="form-group">
                <label class="control-label">Email Address <span>*</span></label>
                <input type="email" name="email" class="form-control white_bg" id="emailaddress" required>
              </div>
              <div class="form-group">
                <label class="control-label">Phone Number <span>*</span></label>
                <input type="text" name="phoneno" class="form-control white_bg" id="phonenumber" maxlength="10" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
              </div>
              <div class="form-group">
                <label class="control-label">Message <span>*</span></label>
                <textarea class="form-control white_bg" name="message" rows="4" required></textarea>
              </div>
              <div class="form-group">
                <button class="btn" type="submit" name="contact" type="submit">Send Message <span class="angle_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span></button>
              </div>
            </form>
          </div>
        </div>
        <div class="col-md-6">
          <h3>Contact Info</h3>
          <div class="contact_detail">
            <ul>
              <li>
                <div class="icon_wrap"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                <div class="contact_info_m">No 67A, Kampung Baru, Mukim Tualak, O6300 Kuala Nerang, Kedah</div>
              </li>
              <li>
                <div class="icon_wrap"><i class="fa fa-phone" aria-hidden="true"></i></div>
                <div class="contact_info_m"><a href="tel:+6062701960">+6 0173440792/ 2015</a></div>
              </li>
              <li>
                <div class="icon_wrap"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
                <div class="contact_info_m"><a href="mailto:bpa@utem.edu.my">nurlizayus@gmail.com</a></div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
<!-- /Contact-us--> 


<!--Footer -->
<?php include('includes/footer.php');?>
<!-- /Footer--> 

<!--Back to top-->
<div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>
<!--/Back to top--> 

<!--Login-Form -->
<?php include('includes/login.php');?>
<!--/Login-Form --> 

<!--Register-Form -->
<?php include('includes/registration.php');?>
<?php include('includes/registercomp.php');?>
<!--/Register-Form --> 

<!--Forgot-password-Form -->
<?php include('includes/forgotpassword.php');?>
<!--/Forgot-password-Form --> 

<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 

<!--bootstrap-slider-JS--> 
<script src="assets/js/bootstrap-slider.min.js"></script> 
<!--Slider-JS--> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>

</body>

<!-- Mirrored from themes.webmasterdriver.net/carforyou/demo/contact-us.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 16 Jun 2017 07:26:55 GMT -->
</html>
