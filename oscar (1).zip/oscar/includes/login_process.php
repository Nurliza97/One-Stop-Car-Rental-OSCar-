<?php
include ('config.php');
session_start();
if(isset($_SESSION['url'])) {
   $url = $_SESSION['url']; // holds url for last page visited.
}
else {
   $url = "index.php";
}

if(isset($_POST['login'])){
  	$email = $_POST["email"];
	$password = $_POST["password"];

	$login = "SELECT * FROM user WHERE email = '".$email."' AND password = '".$password."'";
	$rslt = $conn->query($login);
	if($rslt->num_rows>0){
		while($row = $rslt->fetch_assoc()){
			$status = $row["status"];
			$_SESSION['uid'] = $row["uid"];

			if($status == "superadmin"){
				echo "<meta http-equiv='refresh' content='0; url= ../superadmin/dashboard.php'/>";
			}
			else if($status == "admin" || $status == "staff"){
				$_SESSION['compid'] = $row["compid"];
				echo "<meta http-equiv='refresh' content='0; url= ../admin/dashboard.php'/>";
			}
			else{
				echo "<meta http-equiv='refresh' content='0; url= $url'/>";
			}
			
		}
	}
	else{
		echo "<script>alert('Wrong Email or Password');</script>";
		echo "<meta http-equiv='refresh' content='0; url= ../index.php'/>";
	}
}

?>