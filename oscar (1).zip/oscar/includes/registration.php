<style>
.modal-body {
    padding: 10px 0;
    max-height: calc(100vh - 210px);
    overflow-y: auto;
}
</style>
<div class="modal fade" id="signupform">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">Sign Up</h3>
      </div>
      <div class="modal-body">
        <div class="row" style="max-width: 580px;">
          <div class="signup_wrap">
            <div class="col-md-12 col-sm-6">
              <form  method="post" action="includes/register_process.php">
                <div class="form-group">
                  <input type="text" class="form-control" name="name" placeholder="Full Name" required>
                </div>
				        <div class="form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Email Address" required>
                   <span id="user-availability-status" style="font-size:12px;"></span> 
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="phone" placeholder="Phone Number" maxlength="10" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
                </div>
				        <div class="form-group">
                  <textarea class="form-control" name="address" rows="4" placeholder="Address" required></textarea>
                </div>
				        <div class="form-group">
                  <input type="text" class="form-control" name="postcode" placeholder="Postcode" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" maxlength="5" required>
                </div>
				        <div class="form-group">
                  <input type="text" class="form-control" name="state" placeholder="State" required>
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" name="password2" id="password2" placeholder="Confirm Password" required>
                </div>
                <div class="form-group">
                  <input type="submit" value="Sign Up" name="signup" id="submit" class="btn btn-block">
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer text-center">
        <p>Already got an account? <a href="#loginform" data-toggle="modal" data-dismiss="modal">Login Here</a></p>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
    var password = document.getElementById("password")
      , confirm_password = document.getElementById("password2");

    function validatePassword(){
      if(password.value != confirm_password.value) {
        confirm_password.setCustomValidity("Passwords Don't Match");
      } else {
        confirm_password.setCustomValidity('');
      }
    }

    password.onchange = validatePassword;
    confirm_password.onkeyup = validatePassword;
</script>