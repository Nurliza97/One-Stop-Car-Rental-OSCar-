<style>
.modal-body {
    padding: 10px 0;
    max-height: calc(100vh - 210px);
    overflow-y: auto;
}
</style>
<div class="modal fade" id="registercomp">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">Company Registration</h3>
      </div>
      <div class="modal-body" style="max-height: 500px;">
        <div class="row" style="max-width: 580px; padding-left: 20px;">
          <div class="signup_wrap">
            <div class="col-md-12 col-sm-6">
              <form  method="post" action="includes/register_process.php">
                <div class="form-group">
                  <input type="text" class="form-control" name="name" placeholder="Company Name" required>
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="phone" placeholder="Phone Number" maxlength="10" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
                </div>
				        <div class="form-group">
                  <textarea class="form-control" name="address" rows="4" placeholder="Address" required></textarea>
                </div>
				        <div class="form-group">
                  <input type="text" class="form-control" name="postcode" placeholder="Postcode" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" maxlength="5" required>
                </div>
				        <div class="form-group">
                  <input type="text" class="form-control" name="state" placeholder="State" required>
                </div>
                <div class="form-group">
                  <input type="submit" value="Register" name="compregister" id="submit" class="btn btn-block">
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>