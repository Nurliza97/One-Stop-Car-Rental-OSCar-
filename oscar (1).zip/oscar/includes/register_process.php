<?php
session_start();
include ('config.php');

if(isset($_SESSION["uid"])){
  $uid = $_SESSION["uid"];
}
else{
  $uid = "";
}

if(isset($_POST["signup"])){
  $name = $_POST["name"];
  $uemail = $_POST["email"];
  $phone = $_POST["phone"];
  $address = $_POST["address"];
  $postcode = $_POST["postcode"];
  $state = $_POST["state"];
  $password = $_POST["password"];
  $status = "user";

  $email = "SELECT email FROM user WHERE email = '".$uemail."'";
  $remail = $conn->query($email);
  if($remail->num_rows>0){
    while ($rowemail = $remail->fetch_assoc()) {
      echo "<script>alert('Email already Exist!');</script>";
      echo "<meta http-equiv='refresh' content='0; url= ../index.php'/>";
    }
  }
  else{
    $check = "SELECT MAX(no) AS max FROM user";
    $rcheck = $conn->query($check);
    if($rcheck->num_rows>0){
      while($rowc = $rcheck->fetch_assoc()){
        $max = $rowc["max"];
      }
    }

    if($max < 10){
      $max++;
      $id = "U00" . $max;
    }
    else if($max < 100){
      $max++;
      $id = "U0" . $max;
    }
    else{
      $max++;
      $id = "U" . $max;
    }

    $sql = "INSERT INTO user (uid, name, email, phoneno, address, poscode, state, password, regdate, status) VALUES ('".$id."', '".$name."', '".$uemail."', '".$phone."', '".$address."', '".$postcode."', '".$state."', '".$password."', NOW(), '".$status."')";
    if($conn->query($sql) == TRUE){
       echo "<script>alert('Registration success! Please login.');</script>";
       echo "<meta http-equiv='refresh' content='0; url= ../index.php'/>";
    }
    else{
      echo "<script>alert('Oppss something went wrong.');</script>";
      echo "<meta http-equiv='refresh' content='0; url= ../index.php'/>";
      // echo "Error : " . $sql . "<br>" . $conn->error;
    }
  }
}

if(isset($_POST["compregister"])){

  $name = $_POST["name"];
  $state = $_POST["state"];
  $phone = $_POST["phone"];
  $address = $_POST["address"];
  $postcode = $_POST["postcode"];
  $status = 0;

  $check = "SELECT MAX(no) AS max FROM company";
    $rcheck = $conn->query($check);
    if($rcheck->num_rows>0){
      while($rowc = $rcheck->fetch_assoc()){
        $max = $rowc["max"];
      }
    }

    if($max < 10){
      $max++;
      $id = "C00" . $max;
    }
    else if($max < 100){
      $max++;
      $id = "C0" . $max;
    }
    else{
      $max++;
      $id = "C" . $max;
    }

    $sql = "INSERT INTO company (compid, uid, compname, compadd, compposcode, compstate, phoneno, status) VALUES ('".$id."', '".$uid."', '".$name."', '".$address."', '".$postcode."', '".$state."', '".$phone."', '".$status."')";
    if($conn->query($sql) == TRUE){
       echo "<script>alert('Your regisration completed. Please wait for conformation from admin.');</script>";
       echo "<meta http-equiv='refresh' content='0; url= ../index.php'/>";
    }
    else{
      echo "<script>alert('Oppss something went wrong.');</script>";
      echo "<meta http-equiv='refresh' content='0; url= ../index.php'/>";
    }
}
?>