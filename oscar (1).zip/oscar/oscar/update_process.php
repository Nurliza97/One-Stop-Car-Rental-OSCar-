<?php
include ('includes/config.php');
session_start();

if(isset($_SESSION["uid"])){
  $uid = $_SESSION["uid"];
}
else{
  $uid = "";
}

if(isset($_POST['updateprofile'])){
  	$name = $_POST["name"];
	$phoneno = $_POST["phoneno"];
	$address = $_POST["address"];
	$poscode = $_POST["poscode"];
	$state = $_POST["state"];

	$update = "UPDATE user SET name = '".$name."', phoneno = '".$phoneno."', address = '".$address."', poscode = '".$poscode."', state = '".$state."' WHERE uid = '".$uid."'";
	if($conn->query($update) == TRUE){
		echo "<meta http-equiv='refresh' content='0; url= profile.php?msg'/>";
	}
	else{
		echo "<script>alert('Oppss something went wrong.');</script>";
		echo "<meta http-equiv='refresh' content='0; url= profile.php'/>";
	}
}

if(isset($_POST["updatepass"])){
	$opass = $_POST["oldpassword"];
	$npass = $_POST["password"];

	$check = "SELECT password FROM user WHERE uid = '".$uid."' AND password = '".$opass."'";
	$rcheck = $conn->query($check);
	if($rcheck->num_rows>0){
		$update = "UPDATE user SET password = '".$npass."' WHERE uid = '".$uid."'";
		if($conn->query($update) == TRUE){
			echo "<meta http-equiv='refresh' content='0; url= update-password.php?msg'/>";
		}
		else{
			echo "<script>alert('Oppss something went wrong.');</script>";
			echo "<meta http-equiv='refresh' content='0; url= update-password.php'/>";
		}
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= update-password.php?err'/>";
	}
}

?>