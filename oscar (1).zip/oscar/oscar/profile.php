<?php
session_start();
include('includes/config.php');
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  header('location:index.php');
}

if(isset($_GET["msg"])){
  $msg = "Profile Updated Successfully";
}
else{
  $msg = "";
}

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
    $email = $rowsql["email"];
    $phoneno = $rowsql["phoneno"];
    $address = $rowsql["address"];
    $poscode = $rowsql["poscode"];
    $state = $rowsql["state"];
    $date = $rowsql["regdate"];
    $ndate = date("d-m-Y", strtotime($date));
  }
}
?>
<!DOCTYPE HTML>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title>OSCaR | My Profile</title>
    <!--Bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
    <!--Custome Style -->
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">
    <!--OWL Carousel slider-->
    <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
    <link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
    <!--slick-slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!--bootstrap-slider -->
    <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
    <!--FontAwesome Font Style -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet"> 
    <style>
      .errorWrap {
      padding: 10px;
      margin: 0 0 20px 0;
      background: #fff;
      border-left: 4px solid #dd3d36;
      -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
      box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
      }
      .succWrap{
          padding: 10px;
          margin: 0 0 20px 0;
          background: #fff;
          border-left: 4px solid #5cb85c;
          -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
          box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
      }
    </style>
  </head>
  <body>    
  <!--Header-->
  <?php include('includes/header.php');?>
  <!-- /Header --> 

  <!--Page Header-->
  <section class="page-header profile_page">
    <div class="container">
      <div class="page-header_wrap">
        <div class="page-heading">
          <h1>Your Profile</h1>
        </div>
        <ul class="coustom-breadcrumb">
          <li><a href="#">Home</a></li>
          <li>Profile</li>
        </ul>
      </div>
    </div>
    <!-- Dark Overlay-->
    <div class="dark-overlay"></div>
  </section>
  <!-- /Page Header--> 

  <section class="user_profile inner_pages">
    <div class="container">
      <div class="user_profile_info gray-bg padding_4x4_40">
        <div class="upload_user_logo"> <img src="assets/images/profile.png" alt="image">
        </div>

        <div class="dealer_info">
          <h5><?php echo $name;?></h5>
          <p><?php echo $address;?><br>
            <?php echo $poscode;?>&nbsp;<?php echo $state;?></p>
        </div>
      </div>
    
      <div class="row">
        <div class="col-md-3 col-sm-3">
          <?php include('includes/sidebar.php');?>
        <div class="col-md-6 col-sm-8">
          <div class="profile_wrap">
            <h5 class="uppercase underline">General Settings</h5>
            <?php  
           if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
            <form  method="POST" action="update_process.php">
             <div class="form-group">
                <label class="control-label">Register Date -</label>
               <?php echo $ndate;?>
              </div>
              <div class="form-group">
                <label class="control-label">Full Name</label>
                <input class="form-control white_bg" name="name" value="<?php echo $name;?>" id="fullname" type="text"  required>
              </div>
              <div class="form-group">
                <label class="control-label">Email Address</label>
                <input class="form-control white_bg" value="<?php echo $email;?>" name="emailid" id="email" type="email" required readonly>
              </div>
              <div class="form-group">
                <label class="control-label">Phone Number</label>
                <input class="form-control white_bg" name="phoneno" value="<?php echo $phoneno;?>" id="phone-number" maxlength="10" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" type="text" required>
              </div>
              <div class="form-group">
                <label class="control-label">Your Address</label>
                <textarea class="form-control white_bg" name="address" rows="4" ><?php echo $address;?></textarea>
              </div>
              <div class="form-group">
                <label class="control-label">Postcode</label>
                <input class="form-control white_bg" id="poscode" maxlength="5" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" name="poscode" value="<?php echo $poscode;?>" type="text">
              </div>
  			     <div class="form-group">
                <label class="control-label">State</label>
                <input class="form-control white_bg"  id="state" name="state" value="<?php echo $state?>" type="text">
              </div>
             
              <div class="form-group">
                <button type="submit" name="updateprofile" class="btn">Save Changes <span class="angle_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span></button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/Profile-setting--> 

  <<!--Footer -->
  <?php include('includes/footer.php');?>
  <!-- /Footer--> 

  <!--Back to top-->
  <div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>
  <!--/Back to top--> 

  <!--Login-Form -->
  <?php include('includes/login.php');?>
  <!--/Login-Form --> 

  <!--Register-Form -->
  <?php include('includes/registration.php');?>
  <?php include('includes/registercomp.php');?>
  <!--/Register-Form --> 

  <!--Forgot-password-Form -->
  <?php include('includes/forgotpassword.php');?>
  <!--/Forgot-password-Form --> 

  <!-- Scripts --> 
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script> 
  <script src="assets/js/interface.js"></script> 

  <!--bootstrap-slider-JS--> 
  <script src="assets/js/bootstrap-slider.min.js"></script> 
  <!--Slider-JS--> 
  <script src="assets/js/slick.min.js"></script> 
  <script src="assets/js/owl.carousel.min.js"></script>

  </body>
</html>