<?php
include ('includes/config.php');
session_start();

if(isset($_SESSION["uid"])){
  $uid = $_SESSION["uid"];
}
else{
  header('Location: ../index.php');
}

if(isset($_GET["user"])){
	$userid = $_GET["user"];

	$delete = "DELETE FROM user WHERE uid = '".$userid."'";
	if($conn->query($delete) == TRUE){
		echo "<meta http-equiv='refresh' content='0; url= users.php?msg'/>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= users.php?err'/>";
	}
}

if(isset($_GET["compid"])){
	$compid = $_GET["compid"];
	$userid = $_GET["userid"];

	$delete = "DELETE FROM company WHERE compid = '".$compid."'";
	if($conn->query($delete) == TRUE){
		$user = "UPDATE user SET status = 'user' WHERE uid = '".$userid."'";
		if($conn->query($user) == TRUE){
			echo "<meta http-equiv='refresh' content='0; url= manage-company.php?msg'/>";
		}
		else{
			echo "<meta http-equiv='refresh' content='0; url= manage-company.php?err'/>";
		}
		
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= manage-company.php?err'/>";
	}
}
?>