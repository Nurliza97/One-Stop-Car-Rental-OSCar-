<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  header('Location: ../index.php');
}

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
    $status = $rowsql["status"];
  }
}

$company = "SELECT COUNT(no) AS tcomp FROM company WHERE status = 1";
$rcomp = $conn->query($company);
if($rcomp->num_rows>0){
	while($rowcomp = $rcomp->fetch_assoc()){
		$comp = $rowcomp["tcomp"];
	}
}

$user = "SELECT COUNT(no) AS tuser FROM user WHERE status != 'superadmin'";
$ruser = $conn->query($user);
if($ruser->num_rows>0){
	while($rowuser = $ruser->fetch_assoc()){
		$user = $rowuser["tuser"];
	}
}

$feedback = "SELECT COUNT(no) AS tfeed FROM feedback WHERE status = '1'";
$rfeed = $conn->query($feedback);
if($rfeed->num_rows>0){
	while($rowfeed = $rfeed->fetch_assoc()){
		$feed = $rowfeed["tfeed"];
	}
}

?>
<!DOCTYPE HTML>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>OSCaR | SuperAdmin | Dashboard</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
</head>

<body>
<?php include('includes/header.php');?>
	<div class="ts-main-content">
<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h2 class="page-title">Dashboard</h2>
						<div class="row">
							<div class="col-md-12">
								<div class="row">
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-warning text-light">
												<div class="stat-panel text-center">
													<div class="stat-panel-number h1 "><?php echo $comp;?></div>
													<div class="stat-panel-title text-uppercase">Listed Company</div>
												</div>
											</div>
											<a href="manage-company.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-primary text-light">
												<div class="stat-panel text-center">
													<div class="stat-panel-number h1 "><?php echo $user;?></div>
													<div class="stat-panel-title text-uppercase">Listed Users</div>
												</div>
											</div>
											<a href="users.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-success text-light">
												<div class="stat-panel text-center">
													<div class="stat-panel-number h1 "><?php echo $feed;?></div>
													<div class="stat-panel-title text-uppercase">Listed Testimony</div>
												</div>
											</div>
											<a href="testimonials.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>
</html>