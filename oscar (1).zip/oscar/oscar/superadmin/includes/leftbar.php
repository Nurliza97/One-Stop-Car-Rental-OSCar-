<nav class="ts-sidebar">
	<ul class="ts-sidebar-menu">
		<li class="ts-label">Main</li>
		<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>

		<li><a href="#"><i class="fa fa-building-o"></i> Company</a>
				<ul>
					<li><a href="approve-company.php">Approve Company</a></li>
					<li><a href="manage-company.php">Manage Company</a></li>
				</ul>
		</li>
		<li><a href="testimonials.php"><i class="fa fa-comments-o"></i> Manage Testimonials</a></li>
		<li><a href="users.php"><i class="fa fa-users"></i> Users</a></li>
		<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li>
	</ul>
</nav>