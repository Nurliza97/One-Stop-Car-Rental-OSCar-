<?php
session_start();
include('includes/config.php');
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  header('Location: ../index.php');
}

if(isset($_GET["sfid"])){
	$fid = $_GET["sfid"];

	$update = "UPDATE feedback SET status = '1' WHERE fid = '".$fid."'";
	if($conn->query($update) == TRUE){
		echo "<meta http-equiv='refresh' content='0; url= testimonials.php?msg'/>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= testimonials.php?err'/>";
	}
}

if(isset($_GET["hfid"])){
	$fid = $_GET["hfid"];

	$update = "UPDATE feedback SET status = '0' WHERE fid = '".$fid."'";
	if($conn->query($update) == TRUE){
		echo "<meta http-equiv='refresh' content='0; url= testimonials.php?msg'/>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= testimonials.php?err'/>";
	}
}

if(isset($_GET["acomp"])){
	include 'phpqrcode/qrlib.php'; 	//ini library untuk generate qr code
	$compid = $_GET["acomp"];
	$userid = $_GET["userid"];

	$comp = "SELECT * FROM company WHERE compid = '".$compid."'";
	$rcomp = $conn->query($comp);
	if($rcomp->num_rows>0){
		while($rowcomp = $rcomp->fetch_assoc()){
			$address = $rowcomp["compadd"];
		}
	}

	$text = $address;

	$path = '../admin/img/qr/'; 	//path untuk simpan qrcode
	$name = uniqid().".png";
	$file = $path.$name;			//uniq id untuk every qr code
	

	$ecc = 'L'; 					// $ecc stores error correction capability('L')
	$pixel_Size = 10; 
	$frame_Size = 10; 

	// Generates QR Code and Stores it in directory given 
	QRcode::png($text, $file, $ecc, $pixel_Size, $frame_Size);

	$update = "UPDATE company SET status = '1', qrimg = '".$name."' WHERE compid = '".$compid."'";
	if($conn->query($update) == TRUE){
		$user = "UPDATE user SET status = 'admin', compid = '".$compid."' WHERE uid = '".$userid."'";
		if($conn->query($user) == TRUE){
			echo "<meta http-equiv='refresh' content='0; url= approve-company.php?msg'/>";
		}
		else{
			echo "<meta http-equiv='refresh' content='0; url= approve-company.php?err'/>";
		}
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= approve-company.php?err'/>";
	}
}

if(isset($_GET["rejcomp"])){
	$compid = $_GET["rejcomp"];
	$userid = $_GET["userid"];

	$update = "UPDATE company SET status = '2' WHERE compid = '".$compid."'";
	if($conn->query($update) == TRUE){
		echo "<meta http-equiv='refresh' content='0; url= approve-company.php?msg2'/>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= approve-company.php?err'/>";
	}
}

if(isset($_POST["updatepage"])){
	$pageid = $_POST["pageid"];
	$details = $_POST["details"];

	$update = "UPDATE page SET details = '".$details."' WHERE pageid = '".$pageid."'";
	if($conn->query($update) == TRUE){
		echo "<meta http-equiv='refresh' content='0; url= manage-pages.php?msg&type=$pageid'/>";
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= manage-pages.php?err&type=$pageid'/>";
	}
}

if(isset($_POST["changepass"])){
	$pass = $_POST["password"];
	$npass = $_POST["newpassword"];

	$check = "SELECT * FROM user WHERE uid = '".$uid."'";
	$rcheck = $conn->query($check);
	if($rcheck->num_rows>0){
		while($rowcheck = $rcheck->fetch_assoc()){
			$cpass = $rowcheck["password"];
		}
	}

	if($pass == $cpass){
		$update = "UPDATE user SET password = '".$npass."' WHERE uid = '".$uid."'";
		if($conn->query($update) == TRUE){
			echo "<meta http-equiv='refresh' content='0; url= change-password.php?msg'/>";
		}
		else{
			echo "<meta http-equiv='refresh' content='0; url= change-password.php?err2'/>";
		}
	}
	else{
		echo "<meta http-equiv='refresh' content='0; url= change-password.php?err'/>";
	}

	
}
?>