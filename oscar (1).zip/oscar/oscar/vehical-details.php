<?php
session_start();
include('includes/config.php');
$_SESSION['url'] = $_SERVER['REQUEST_URI'];
if(isset($_SESSION['uid'])){ 
  $uid = $_SESSION["uid"];
}
else{
  $uid = "";
}

if(isset($_GET["kid"])){
  $kid = $_GET["kid"];
}
else{
  $kid = "";
}

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
    $email = $rowsql["email"];
    $phoneno = $rowsql["phoneno"];
    $address = $rowsql["address"];
    $poscode = $rowsql["poscode"];
    $state = $rowsql["state"];
    $date = $rowsql["regdate"];
    $ndate = date("d-m-Y", strtotime($date));
  }
}

$car = "SELECT * FROM car AS a INNER JOIN cardet AS b ON a.carid = b.carid INNER JOIN company AS c ON a.compid = c.compid WHERE a.carid = '".$kid."'";
$rcar = $conn->query($car);
if($rcar->num_rows>0){
  while($rowcar = $rcar->fetch_assoc()){
    $carno = $rowcar["carno"];
    $brand = $rowcar["brand"];
    $title = $rowcar["title"];
    $rentalprice = $rowcar["rentalprice"];
    $priceday = $rowcar["priceday"];
    $state = $rowcar["state"];
    $modelyear = $rowcar["modelyear"];
    $seatcapacity = $rowcar["seatcapacity"];
    $carimg1 = $rowcar["carimg1"];
    $carimg2 = $rowcar["carimg2"];
    $carimg3 = $rowcar["carimg3"];
    $aircond = $rowcar["aircond"];
    $doorlock = $rowcar["doorlock"];
    $antilock = $rowcar["antilock"];
    $breakeassist = $rowcar["breakeassist"];
    $powersteering = $rowcar["powersteering"];
    $airbag = $rowcar["airbag"];
    $powerwindow = $rowcar["powerwindow"];
    $cdplayer = $rowcar["cdplayer"];
    $centrallock = $rowcar["centrallock"];
    $crashsensor = $rowcar["crashsensor"];
    $leatherseat = $rowcar["leatherseat"];
    $passangerairbag = $rowcar["passangerairbag"];
    $regdate = $rowcar["regdate"];
    $compname = $rowcar["compname"];
    $comptel = $rowcar["phoneno"];
  }
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
<title>OSCaR | Vehicle Details</title>
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
<!--slick-slider -->
<link href="assets/css/slick.css" rel="stylesheet">
<!--bootstrap-slider -->
<link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">

<style type="text/css">
  .the-images {
    /* This is where magic happens */
    max-width: 100%;
    max-height: 350px;
    width: auto;

    display: block;
    margin: 0 auto;
  }
</style>
</head>
<body>
 

<!--Header-->
<?php include('includes/header.php');?>
<!-- /Header --> 

<!--Listing-Image-Slider-->

<div class="col-md-12 the-images">
  <div class="col-md-4" >
    <img src="admin/img/vehicleimages/<?php echo $carimg1;?>" class="img-responsive" alt="image" >
  </div>
  <div class="col-md-4" >
    <img src="admin/img/vehicleimages/<?php echo $carimg2;?>" class="img-responsive" alt="image" >
  </div>
  <div class="col-md-4" >
    <img src="admin/img/vehicleimages/<?php echo $carimg3;?>" class="img-responsive" alt="image" >
  </div>
</div>

<!--/Listing-Image-Slider-->
<!--Listing-detail-->
<section class="listing-detail">
  <div class="container">
    <div class="listing_detail_head row" style="padding-top: 250px;">
      <div class="col-md-9">
        <h2><?php echo $brand;?> , <?php echo $title;?></h2>
      </div>
      <div class="col-md-3">
        <div class="price_info">
          <p>RM <?php echo $priceday;?> </p>Per Day
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8">
        <div class="main_features">
          <ul>
            <li> <i class="fa fa-calendar" aria-hidden="true"></i>
              <h5><?php echo $modelyear;?></h5>
              <p>Register Year</p>
            </li>
            <li> <i class="fa fa-cogs" aria-hidden="true"></i>
              <h5><?php echo $state;?></h5>
              <p>Your State</p>
            </li>
       
            <li> <i class="fa fa-user-plus" aria-hidden="true"></i>
              <h5><?php echo $seatcapacity;?></h5>
              <p>Seats</p>
            </li>
          </ul>
        </div>
        <div class="listing_more_info">
          <div class="listing_detail_wrap"> 
            <!-- Nav tabs -->
            <ul class="nav nav-tabs gray-bg" role="tablist">
              <li role="presentation" class="active"><a href="#rental-price" aria-controls="rental-price" role="tab" data-toggle="tab">Rental Description</a></li>
          
              <li role="presentation"><a href="#accessories" aria-controls="accessories" role="tab" data-toggle="tab">Accessories</a></li>
            </ul>
            
            <!-- Tab panes -->
            <div class="tab-content"> 
              <!-- vehicle-overview -->
              <div role="tabpanel" class="tab-pane active" id="rental-price">
                
                <p>Price: <?php echo $rentalprice;?></p>
                <p>Company Name: <b><?php echo $compname;?></b></p>
                <p>Tel No: <b>+06 <?php echo $comptel;?></b></p>
              </div>
              
              
              <!-- Accessories -->
              <div role="tabpanel" class="tab-pane" id="accessories"> 
                <!--Accessories-->
                <table>
                  <thead>
                    <tr>
                      <th colspan="2">Accessories</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Air Conditioner</td>
                      <?php 
                      if($aircond == 1){
                        ?>
                        <td><i class="fa fa-check" aria-hidden="true"></i></td>
                        <?php 
                      } 
                      else { 
                        ?> 
                        <td><i class="fa fa-close" aria-hidden="true"></i></td>
                        <?php 
                      } 
                      ?> 
                    </tr>

                    <tr>
                      <td>AntiLock Braking System</td>
                      <?php 
                      if($antilock == 1){
                        ?>
                        <td><i class="fa fa-check" aria-hidden="true"></i></td>
                        <?php 
                      } 
                      else {
                        ?>
                        <td><i class="fa fa-close" aria-hidden="true"></i></td>
                        <?php 
                      } 
                      ?>
                    </tr>

                  <tr>
                    <td>Power Steering</td>
                    <?php 
                    if($powersteering == 1){
                      ?>
                      <td><i class="fa fa-check" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    else { 
                      ?>
                      <td><i class="fa fa-close" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    ?>
                  </tr>
                   
                  <tr>
                    <td>Power Windows</td>
                      <?php 
                      if($powerwindow == 1){
                        ?>
                        <td><i class="fa fa-check" aria-hidden="true"></i></td>
                        <?php 
                      } 
                      else { 
                        ?>
                        <td><i class="fa fa-close" aria-hidden="true"></i></td>
                        <?php
                      } 
                      ?>
                  </tr>
                   
                  <tr>
                    <td>CD Player</td>
                    <?php 
                    if($cdplayer == 1){
                      ?>
                      <td><i class="fa fa-check" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    else { 
                      ?>
                      <td><i class="fa fa-close" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    ?>
                  </tr>

                  <tr>
                    <td>Leather Seats</td>
                      <?php 
                      if($leatherseat == 1){
                        ?>
                        <td><i class="fa fa-check" aria-hidden="true"></i></td>
                      <?php 
                    }
                    else { 
                      ?>
                      <td><i class="fa fa-close" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    ?>
                  </tr>

                  <tr>
                    <td>Central Locking</td>
                    <?php 
                    if($centrallock == 1){
                      ?>
                      <td><i class="fa fa-check" aria-hidden="true"></i></td>
                      <?php 
                    }
                    else { 
                      ?>
                      <td><i class="fa fa-close" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    ?>
                  </tr>

                  <tr>
                    <td>Power Door Locks</td>
                    <?php 
                    if($doorlock == 1){
                      ?>
                      <td><i class="fa fa-check" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    else { 
                      ?>
                      <td><i class="fa fa-close" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    ?>
                  </tr>

                  <tr>
                    <td>Brake Assist</td>
                    <?php 
                    if($breakeassist == 1){
                      ?>
                      <td><i class="fa fa-check" aria-hidden="true"></i></td>
                      <?php  
                    } 
                    else { 
                      ?>
                      <td><i class="fa fa-close" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    ?>
                  </tr>

                  <tr>
                    <td>Driver Airbag</td>
                    <?php 
                    if($airbag == 1){
                      ?>
                      <td><i class="fa fa-check" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    else { 
                      ?>
                      <td><i class="fa fa-close" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    ?>
                  </tr>
                   
                  <tr>
                    <td>Passenger Airbag</td>
                    <?php 
                    if($passangerairbag == 1){
                      ?>
                      <td><i class="fa fa-check" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    else {
                      ?>
                      <td><i class="fa fa-close" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    ?>
                  </tr>

                  <tr>
                    <td>Crash Sensor</td>
                    <?php 
                    if($crashsensor==1){
                      ?>
                      <td><i class="fa fa-check" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    else { 
                      ?>
                      <td><i class="fa fa-close" aria-hidden="true"></i></td>
                      <?php 
                    } 
                    ?>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
      
      <!--Side-Bar-->
      <aside class="col-md-4">        
        <div class="sidebar_widget">
          <div class="widget_heading">
            <h5><i class="fa fa-envelope" aria-hidden="true"></i>Book Now</h5>
          </div>
          <form action="#" method="post">
            <?php 
            if($uid != ""){
              ?>
              <div class="form-group" style="text-align:center">
                <a href="booking-hourly.php?kid=<?php echo $kid;?>"><input type="button" class="btn"  name="hourly" value="Hourly">
				        &nbsp;
                <a href="booking-daily.php?kid=<?php echo $kid;?>"><input type="button" class="btn"  name="daily" value="Daily"></a>
              </div>
              <?php 
            } 
            else { 
              ?>
			        <center><a href="#loginform" class="btn btn-xs uppercase" data-toggle="modal" data-dismiss="modal">Login For Booking</a></center>
              <?php 
            } 
            ?>
          </form>
        </div>
      </aside>
      <!--/Side-Bar--> 
    </div>
    
    <div class="space-20"></div>
    <div class="divider"></div>
    
    <!--Similar-Cars-->
    <div class="similar_cars">
      <h3>Similar Cars</h3>
      <div class="row"> 
        <?php
        $similar = "SELECT *, a.carid AS skid FROM car AS a INNER JOIN cardet AS b ON a.carid = b.carid WHERE a.carid != '".$kid."' AND a.brand = '".$brand."'";
        $rsimilar = $conn->query($similar);
        if($rsimilar->num_rows>0){
          while($rowsimilar = $rsimilar->fetch_assoc()){
            $skid = $rowsimilar["skid"];
            $carimg = $rowsimilar["carimg1"];
            $sbrand = $rowsimilar["brand"];
            $stitle = $rowsimilar["title"];
            $spriceday = $rowsimilar["priceday"];
            $sseat = $rowsimilar["seatcapacity"];
            $smodel = $rowsimilar["modelyear"];
            $sstate = $rowsimilar["state"];
            ?>
            <div class="col-md-3 grid_listing">
              <div class="product-listing-m gray-bg">
                <div class="product-listing-img"> <a href="vehical-details.php?kid=<?php echo $skid;?>"><img src="admin/img/vehicleimages/<?php echo $carimg;?>" class="img-responsive" alt="image" /> </a>
                </div>
                <div class="product-listing-content">
                  <h5><a href="vehical-details.php?kid=<?php echo $skid;?>"><?php echo $sbrand;?> , <?php echo $stitle;?></a></h5>
                  <p class="list-price">RM <?php echo $spriceday;?></p>
                  <ul class="features_list">
                 <li><i class="fa fa-user" aria-hidden="true"></i><?php echo $sseat;?> seats</li>
                    <li><i class="fa fa-calendar" aria-hidden="true"></i><?php echo $smodel;?> model</li>
                    <li><i class="fa fa-car" aria-hidden="true"></i><?php echo $sstate;?></li>
                  </ul>
                </div>
              </div>
            </div>
            <?php
          }
        }
        ?>
      </div>
    </div>
    <!--/Similar-Cars--> 
    
  </div>
</section>
<!--/Listing-detail--> 

<!--Footer -->
<?php include('includes/footer.php');?>
<!-- /Footer--> 

<!--Back to top-->
<div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>
<!--/Back to top--> 

<!--Login-Form -->
<?php include('includes/login.php');?>
<!--/Login-Form --> 

<!--Register-Form -->
<?php include('includes/registration.php');?>
<?php include('includes/registercomp.php');?>
<!--/Register-Form --> 

<!--Forgot-password-Form -->
<?php include('includes/forgotpassword.php');?>
<!--/Forgot-password-Form -->

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 
<script src="assets/switcher/js/switcher.js"></script>
<script src="assets/js/bootstrap-slider.min.js"></script> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>

</body>
</html>