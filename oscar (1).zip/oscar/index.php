<?php 
session_start();
include('includes/config.php');
$_SESSION['url'] = $_SERVER['REQUEST_URI'];
if(isset($_SESSION["uid"])){
  $uid = $_SESSION["uid"];
}
else{
  $uid = "";
}

$sql = "SELECT * FROM user WHERE uid = '".$uid."'";
$rsql = $conn->query($sql);
if($rsql->num_rows>0){
  while($rowsql = $rsql->fetch_assoc()){
    $name = $rowsql["name"];
  }
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="keywords" content="">
  <meta name="description" content="">
  <title>OSCaR</title>
  <!--Bootstrap -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
  <link rel="stylesheet" href="assets/css/style.css" type="text/css">
  <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
  <link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
  <link href="assets/css/slick.css" rel="stylesheet">
  <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
  <link href="assets/css/font-awesome.min.css" rel="stylesheet">
	<link rel="stylesheet" id="switcher-css" type="text/css" href="assets/switcher/css/switcher.css" media="all" />

  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet"> 
</head>
<body>
       
<!--Header-->
<?php include('includes/header.php');?>
<!-- /Header --> 

<!-- Resent Cat-->
<section class="section-padding gray-bg">
  <div class="container">
    <div class="section-header text-center">
      <h2>Place to find <span>Rental Car</span></h2>
    </div>
    <div class="row"> 
      
      <!-- Nav tabs -->
      <div class="recent-tab">
        <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" class="active"><a href="#resentnewcar" role="tab" data-toggle="tab">New Car</a></li>
        </ul>
      </div>
      <!-- New Car list -->
      <div class="tab-content">
        <div role="tabpanel" class="tab-pane active" id="resentnewcar">
          <?php
          $car = "SELECT * FROM car AS a INNER JOIN cardet AS b ON a.carid = b.carid WHERE a.status = 'free' ORDER BY a.createdate ASC LIMIT 6";
          $rcar = $conn->query($car);
          if($rcar->num_rows>0){
            while($rowcar = $rcar->fetch_assoc()){
              $kid = $rowcar["carid"];
              $title = $rowcar["title"];
              $brand = $rowcar["brand"];
              $seat = $rowcar["seatcapacity"];
              $model = $rowcar["modelyear"];
              $state = $rowcar["state"];
              $price = $rowcar["priceday"];
              $img = $rowcar["carimg1"];
              ?>
              <div class="col-list-3">
                <div class="recent-car-list">
                  <div class="car-info-box"> 
                    <a href="vehical-details.php?kid=<?php echo $kid ?>" class="img-responsive" alt="image" style="width: 100%;"><img src="admin/img/vehicleimages/<?php echo $img;?>" class="img-responsive" style="max-height: 200px; margin: auto;" alt="image"></a>
                    <ul>
                      <li>
                        <i class="fa fa-car" aria-hidden="true"></i>
                        <?php echo $state ?>
                      </li>
                      <li>
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                        <?php echo $model ?> Model
                      </li>
                      <li>
                        <i class="fa fa-user" aria-hidden="true"></i>
                        <?php echo $seat ?> seats
                      </li>
                    </ul>
                  </div>
                  <div class="car-title-m">
                    <h6>
                      <a href="vehical-details.php?kid=<?php echo $kid ?>">
                        <?php echo $brand ?> , <?php echo $title ?>
                      </a>
                    </h6>
                    <span class="price">RM <?php echo $price ?>/Day</span> 
                  </div>
                </div>
              </div>
              <?php
            }
          }
          ?> 
      </div>
    </div>
  </div>
</section>

<!-- Facts -->
<section class="fun-facts-section">
  <div class="container div_zindex">
    <div class="row">
      <div class="col-lg-3 col-xs-6 col-sm-3">
        <div class="fun-facts-m">
          <div class="cell">
            <h2><i class="fa fa-calendar" aria-hidden="true"></i>10+</h2>
            <p>Years In Business</p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6 col-sm-3">
        <div class="fun-facts-m">
          <div class="cell">
            <h2><i class="fa fa-car" aria-hidden="true"></i>300+</h2>
            <p>Cars Rented</p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6 col-sm-3">
        <div class="fun-facts-m">
          <div class="cell">
            <h2><i class="fa fa-user-circle-o" aria-hidden="true"></i>300+</h2>
            <p>Registered Users</p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6 col-sm-3">
        <div class="fun-facts-m">
          <div class="cell">
            <h2><i class="fa fa-user-circle-o" aria-hidden="true"></i>250+</h2>
            <p>Satisfied Customers</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Dark Overlay-->
  <div class="dark-overlay"></div>
</section>
<!-- /Fun Facts--> 


<!--Testimonial -->
<section class="section-padding testimonial-section parallex-bg">
  <div class="container div_zindex">
    <div class="section-header white-text text-center">
      <h2>Our Satisfied <span>Customers</span></h2>
    </div>
    <div class="row">
      <?php
      $testimonial = "SELECT * FROM feedback AS a INNER JOIN user AS b on a.uid = b.uid WHERE a.status = 1";
      $rtest = $conn->query($testimonial);
      if($rtest->num_rows>0){
        while ($rowtest = $rtest->fetch_assoc()) {
          $username = $rowtest["name"];
          $message = $rowtest["message"];

          ?>
          <div id="testimonial-slider">
            <div class="testimonial-m">
              <div class="testimonial-content">
                <div class="testimonial-heading">
                  <h5><?php echo $username ?></h5>
                  <p><?php echo $message ?></p>
                </div>
              </div>
            </div>
          </div>
          <?php
        }
      }
      else{
        ?>
        <div class="col-lg-12">
          <h5 style="font-weight: bold; color: #fff;">Sorry, no new testimony</h5>
        </div>
        <?php
      }
      ?>
      
    </div>
  </div>
  <!-- Dark Overlay-->
  <div class="dark-overlay"></div>
</section>
<!-- /Testimonial--> 


<!--Footer -->
<?php include('includes/footer.php');?>
<!-- /Footer--> 

<!--Back to top-->
<div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>
<!--/Back to top--> 

<!--Login-Form -->
<?php include('includes/login.php');?>
<!--/Login-Form --> 

<!--Register-Form -->
<?php include('includes/registration.php');?>
<?php include('includes/registercomp.php');?>
<!--/Register-Form --> 

<!--Forgot-password-Form -->
<?php include('includes/forgotpassword.php');?>
<!--/Forgot-password-Form --> 

<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 

<!--bootstrap-slider-JS--> 
<script src="assets/js/bootstrap-slider.min.js"></script> 
<!--Slider-JS--> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>

</body>

<!-- Mirrored from themes.webmasterdriver.net/carforyou/demo/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 16 Jun 2017 07:22:11 GMT -->
</html>